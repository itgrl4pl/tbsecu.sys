-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 02, 2026 at 06:04 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `kathi_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin_behavior`
--

CREATE TABLE `admin_behavior` (
  `id` int(11) NOT NULL,
  `admin_id` int(11) NOT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `user_agent` text DEFAULT NULL,
  `login_hour` int(2) DEFAULT NULL,
  `login_day` int(1) DEFAULT NULL,
  `login_date` date DEFAULT NULL,
  `login_time` datetime NOT NULL,
  `is_success` tinyint(1) DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `admin_behavior`
--

INSERT INTO `admin_behavior` (`id`, `admin_id`, `ip_address`, `user_agent`, `login_hour`, `login_day`, `login_date`, `login_time`, `is_success`) VALUES
(1, 1, '192.168.1.122', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36', 15, 1, '2026-03-02', '2026-03-02 22:29:48', 1),
(2, 1, '192.168.1.200', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', 15, 1, '2026-03-02', '2026-03-02 22:30:08', 1),
(3, 1, '192.168.1.200', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', 3, 1, '2026-03-02', '2026-03-02 22:30:08', 1),
(4, 1, '192.168.1.200', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', 15, 1, '2026-03-02', '2026-03-02 15:30:08', 1),
(5, 1, '192.168.1.200', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', 15, 1, '2026-03-02', '2026-03-02 15:29:08', 1),
(6, 1, '192.168.1.200', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', 15, 1, '2026-03-02', '2026-03-02 15:28:08', 1),
(7, 1, '192.168.1.200', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', 15, 1, '2026-03-02', '2026-03-02 15:27:08', 1),
(8, 1, '192.168.1.189', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', 15, 1, '2026-03-02', '2026-03-02 22:32:15', 1),
(9, 1, '192.168.1.189', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', 3, 1, '2026-03-02', '2026-03-02 22:32:15', 1),
(10, 1, '192.168.1.189', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', 15, 1, '2026-03-02', '2026-03-02 15:32:15', 1),
(11, 1, '192.168.1.189', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', 15, 1, '2026-03-02', '2026-03-02 15:31:15', 1),
(12, 1, '192.168.1.189', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', 15, 1, '2026-03-02', '2026-03-02 15:30:15', 1),
(13, 1, '192.168.1.189', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', 15, 1, '2026-03-02', '2026-03-02 15:29:15', 1),
(14, 1, '192.168.1.116', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', 15, 1, '2026-03-02', '2026-03-02 22:32:45', 1),
(15, 1, '192.168.1.116', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', 3, 1, '2026-03-02', '2026-03-02 22:32:45', 1),
(16, 1, '192.168.1.116', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', 15, 1, '2026-03-02', '2026-03-02 15:32:45', 1),
(17, 1, '192.168.1.116', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', 15, 1, '2026-03-02', '2026-03-02 15:31:45', 1),
(18, 1, '192.168.1.116', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', 15, 1, '2026-03-02', '2026-03-02 15:30:45', 1),
(19, 1, '192.168.1.116', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', 15, 1, '2026-03-02', '2026-03-02 15:29:45', 1),
(20, 1, '192.168.1.146', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', 15, 1, '2026-03-02', '2026-03-02 22:33:04', 1),
(21, 1, '192.168.1.146', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', 3, 1, '2026-03-02', '2026-03-02 22:33:04', 1),
(22, 1, '192.168.1.146', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', 15, 1, '2026-03-02', '2026-03-02 15:33:04', 1),
(23, 1, '192.168.1.146', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', 15, 1, '2026-03-02', '2026-03-02 15:32:04', 1),
(24, 1, '192.168.1.146', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', 15, 1, '2026-03-02', '2026-03-02 15:31:04', 1),
(25, 1, '192.168.1.146', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', 15, 1, '2026-03-02', '2026-03-02 15:30:04', 1),
(26, 1, '192.168.1.119', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36', 16, 1, '2026-03-02', '2026-03-02 23:25:45', 1),
(27, 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', 16, 1, '2026-03-02', '2026-03-02 23:37:38', 1),
(28, 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', 16, 1, '2026-03-02', '2026-03-02 23:41:03', 1),
(29, 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36 Edg/145.0.0.0', 16, 1, '2026-03-02', '2026-03-02 23:41:45', 1);

-- --------------------------------------------------------

--
-- Table structure for table `admin_login_history`
--

CREATE TABLE `admin_login_history` (
  `id` int(11) NOT NULL,
  `admin_id` int(11) NOT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `user_agent` text DEFAULT NULL,
  `status` enum('success','failed') DEFAULT 'success',
  `login_time` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `admin_login_history`
--

INSERT INTO `admin_login_history` (`id`, `admin_id`, `ip_address`, `user_agent`, `status`, `login_time`) VALUES
(1, 0, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36 Edg/145.0.0.0', 'failed', '2026-03-02 23:49:58'),
(2, 0, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36 Edg/145.0.0.0', 'failed', '2026-03-02 23:50:04');

-- --------------------------------------------------------

--
-- Table structure for table `admin_sessions`
--

CREATE TABLE `admin_sessions` (
  `id` int(11) NOT NULL,
  `admin_id` int(11) NOT NULL,
  `fingerprint` varchar(64) NOT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `user_agent` text DEFAULT NULL,
  `login_time` datetime NOT NULL,
  `logout_time` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `admin_sessions`
--

INSERT INTO `admin_sessions` (`id`, `admin_id`, `fingerprint`, `ip_address`, `user_agent`, `login_time`, `logout_time`) VALUES
(1, 1, '46d58647af4b6e60895ea8bdf0f37dabd81fe7d2a0b5e5b0d040c9bfef806ccb', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '2026-03-02 23:37:38', NULL),
(2, 1, '46d58647af4b6e60895ea8bdf0f37dabd81fe7d2a0b5e5b0d040c9bfef806ccb', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '2026-03-02 23:41:03', NULL),
(3, 1, '4313c108c03badb48fd53b73090cf660f1e27cf161ee09770eced9fdeee1137a', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36 Edg/145.0.0.0', '2026-03-02 23:41:45', '2026-03-02 23:44:52');

-- --------------------------------------------------------

--
-- Table structure for table `anomaly_alerts`
--

CREATE TABLE `anomaly_alerts` (
  `id` int(11) NOT NULL,
  `anomaly_type` varchar(50) NOT NULL,
  `description` text NOT NULL,
  `severity` enum('low','medium','high') DEFAULT 'medium',
  `detected_at` datetime NOT NULL,
  `is_resolved` tinyint(1) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `anomaly_alerts`
--

INSERT INTO `anomaly_alerts` (`id`, `anomaly_type`, `description`, `severity`, `detected_at`, `is_resolved`) VALUES
(1, 'rapid_changes', 'Unusual activity: 20 changes in 1 minute', 'high', '2026-03-02 23:59:20', 1),
(2, 'rapid_changes', 'Unusual activity: 21 changes in 1 minute', 'high', '2026-03-02 23:59:20', 1),
(3, 'rapid_changes', 'Unusual activity: 22 changes in 1 minute', 'high', '2026-03-02 23:59:20', 1),
(4, 'rapid_changes', 'Unusual activity: 23 changes in 1 minute', 'high', '2026-03-02 23:59:20', 1),
(5, 'rapid_changes', 'Unusual activity: 24 changes in 1 minute', 'high', '2026-03-02 23:59:20', 1),
(6, 'rapid_changes', 'Unusual activity: 25 changes in 1 minute', 'high', '2026-03-02 23:59:20', 1),
(7, 'rapid_changes', 'Unusual activity: 26 changes in 1 minute', 'high', '2026-03-02 23:59:20', 0),
(8, 'rapid_changes', 'Unusual activity: 27 changes in 1 minute', 'high', '2026-03-02 23:59:20', 0),
(9, 'rapid_changes', 'Unusual activity: 28 changes in 1 minute', 'high', '2026-03-02 23:59:20', 1),
(10, 'rapid_changes', 'Unusual activity: 29 changes in 1 minute', 'high', '2026-03-02 23:59:41', 0),
(11, 'mass_deletion', 'Mass deletion detected: 10 records deleted in 5 minutes', 'high', '2026-03-03 00:50:01', 0),
(12, 'mass_deletion', 'Mass deletion detected: 11 records deleted in 5 minutes', 'high', '2026-03-03 00:50:01', 0),
(13, 'mass_deletion', 'Mass deletion detected: 12 records deleted in 5 minutes', 'high', '2026-03-03 00:50:01', 0);

-- --------------------------------------------------------

--
-- Table structure for table `audit_log`
--

CREATE TABLE `audit_log` (
  `id` int(11) NOT NULL,
  `admin_id` int(11) DEFAULT NULL,
  `table_name` varchar(100) NOT NULL,
  `action` varchar(50) NOT NULL,
  `record_id` int(11) NOT NULL,
  `old_value` text DEFAULT NULL,
  `new_value` text NOT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `change_time` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `audit_log`
--

INSERT INTO `audit_log` (`id`, `admin_id`, `table_name`, `action`, `record_id`, `old_value`, `new_value`, `ip_address`, `change_time`) VALUES
(1, 1, 'tbl_booking', 'INSERT', 7745, '', '{\"name\":\"Test Customer\",\"status\":\"new\"}', '::1', '2026-03-02 23:59:11'),
(2, 1, 'tbl_booking', 'UPDATE', 123, '{\"name\":\"Old Name\"}', '{\"name\":\"New Name\"}', '::1', '2026-03-02 23:59:13'),
(3, 1, 'tbl_booking', 'DELETE', 123, '{\"name\":\"Deleted Customer\"}', '', '::1', '2026-03-02 23:59:15'),
(4, 1, 'tbl_booking', 'UPDATE', 0, '', '{\"status\":\"changed\"}', '::1', '2026-03-02 23:59:20'),
(5, 1, 'tbl_booking', 'UPDATE', 1, '', '{\"status\":\"changed\"}', '::1', '2026-03-02 23:59:20'),
(6, 1, 'tbl_booking', 'UPDATE', 2, '', '{\"status\":\"changed\"}', '::1', '2026-03-02 23:59:20'),
(7, 1, 'tbl_booking', 'UPDATE', 3, '', '{\"status\":\"changed\"}', '::1', '2026-03-02 23:59:20'),
(8, 1, 'tbl_booking', 'UPDATE', 4, '', '{\"status\":\"changed\"}', '::1', '2026-03-02 23:59:20'),
(9, 1, 'tbl_booking', 'UPDATE', 5, '', '{\"status\":\"changed\"}', '::1', '2026-03-02 23:59:20'),
(10, 1, 'tbl_booking', 'UPDATE', 6, '', '{\"status\":\"changed\"}', '::1', '2026-03-02 23:59:20'),
(11, 1, 'tbl_booking', 'UPDATE', 7, '', '{\"status\":\"changed\"}', '::1', '2026-03-02 23:59:20'),
(12, 1, 'tbl_booking', 'UPDATE', 8, '', '{\"status\":\"changed\"}', '::1', '2026-03-02 23:59:20'),
(13, 1, 'tbl_booking', 'UPDATE', 9, '', '{\"status\":\"changed\"}', '::1', '2026-03-02 23:59:20'),
(14, 1, 'tbl_booking', 'UPDATE', 10, '', '{\"status\":\"changed\"}', '::1', '2026-03-02 23:59:20'),
(15, 1, 'tbl_booking', 'UPDATE', 11, '', '{\"status\":\"changed\"}', '::1', '2026-03-02 23:59:20'),
(16, 1, 'tbl_booking', 'UPDATE', 12, '', '{\"status\":\"changed\"}', '::1', '2026-03-02 23:59:20'),
(17, 1, 'tbl_booking', 'UPDATE', 13, '', '{\"status\":\"changed\"}', '::1', '2026-03-02 23:59:20'),
(18, 1, 'tbl_booking', 'UPDATE', 14, '', '{\"status\":\"changed\"}', '::1', '2026-03-02 23:59:20'),
(19, 1, 'tbl_booking', 'UPDATE', 15, '', '{\"status\":\"changed\"}', '::1', '2026-03-02 23:59:20'),
(20, 1, 'tbl_booking', 'UPDATE', 16, '', '{\"status\":\"changed\"}', '::1', '2026-03-02 23:59:20'),
(21, 1, 'tbl_booking', 'UPDATE', 17, '', '{\"status\":\"changed\"}', '::1', '2026-03-02 23:59:20'),
(22, 1, 'tbl_booking', 'UPDATE', 18, '', '{\"status\":\"changed\"}', '::1', '2026-03-02 23:59:20'),
(23, 1, 'tbl_booking', 'UPDATE', 19, '', '{\"status\":\"changed\"}', '::1', '2026-03-02 23:59:20'),
(24, 1, 'tbl_booking', 'UPDATE', 20, '', '{\"status\":\"changed\"}', '::1', '2026-03-02 23:59:20'),
(25, 1, 'tbl_booking', 'UPDATE', 21, '', '{\"status\":\"changed\"}', '::1', '2026-03-02 23:59:20'),
(26, 1, 'tbl_booking', 'UPDATE', 22, '', '{\"status\":\"changed\"}', '::1', '2026-03-02 23:59:20'),
(27, 1, 'tbl_booking', 'UPDATE', 23, '', '{\"status\":\"changed\"}', '::1', '2026-03-02 23:59:20'),
(28, 1, 'tbl_booking', 'UPDATE', 24, '', '{\"status\":\"changed\"}', '::1', '2026-03-02 23:59:20'),
(29, 1, 'tbl_booking', 'SELECT', 0, '', '', '::1', '2026-03-02 23:59:41'),
(30, 1, 'tbl_booking', 'SELECT', 0, '', '', '::1', '2026-03-03 00:49:40'),
(31, 1, 'tbl_booking', 'DELETE', 0, '{\"name\":\"Bulk Delete\"}', '', '::1', '2026-03-03 00:50:01'),
(32, 1, 'tbl_booking', 'DELETE', 1, '{\"name\":\"Bulk Delete\"}', '', '::1', '2026-03-03 00:50:01'),
(33, 1, 'tbl_booking', 'DELETE', 2, '{\"name\":\"Bulk Delete\"}', '', '::1', '2026-03-03 00:50:01'),
(34, 1, 'tbl_booking', 'DELETE', 3, '{\"name\":\"Bulk Delete\"}', '', '::1', '2026-03-03 00:50:01'),
(35, 1, 'tbl_booking', 'DELETE', 4, '{\"name\":\"Bulk Delete\"}', '', '::1', '2026-03-03 00:50:01'),
(36, 1, 'tbl_booking', 'DELETE', 5, '{\"name\":\"Bulk Delete\"}', '', '::1', '2026-03-03 00:50:01'),
(37, 1, 'tbl_booking', 'DELETE', 6, '{\"name\":\"Bulk Delete\"}', '', '::1', '2026-03-03 00:50:01'),
(38, 1, 'tbl_booking', 'DELETE', 7, '{\"name\":\"Bulk Delete\"}', '', '::1', '2026-03-03 00:50:01'),
(39, 1, 'tbl_booking', 'DELETE', 8, '{\"name\":\"Bulk Delete\"}', '', '::1', '2026-03-03 00:50:01'),
(40, 1, 'tbl_booking', 'DELETE', 9, '{\"name\":\"Bulk Delete\"}', '', '::1', '2026-03-03 00:50:01'),
(41, 1, 'tbl_booking', 'DELETE', 10, '{\"name\":\"Bulk Delete\"}', '', '::1', '2026-03-03 00:50:01'),
(42, 1, 'tbl_booking', 'DELETE', 11, '{\"name\":\"Bulk Delete\"}', '', '::1', '2026-03-03 00:50:01');

-- --------------------------------------------------------

--
-- Table structure for table `data_tampering_log`
--

CREATE TABLE `data_tampering_log` (
  `id` int(11) NOT NULL,
  `table_name` varchar(100) NOT NULL,
  `record_id` int(11) NOT NULL,
  `expected_hash` varchar(64) NOT NULL,
  `actual_hash` varchar(64) NOT NULL,
  `detected_at` datetime NOT NULL,
  `ip_address` varchar(45) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `pending_approvals`
--

CREATE TABLE `pending_approvals` (
  `id` int(11) NOT NULL,
  `admin_id` int(11) NOT NULL,
  `action_type` varchar(50) NOT NULL,
  `action_details` text NOT NULL,
  `approval_token` varchar(64) NOT NULL,
  `approval_code` varchar(10) NOT NULL,
  `status` enum('pending','approved','rejected','expired') DEFAULT 'pending',
  `created_at` datetime NOT NULL,
  `expires_at` datetime NOT NULL,
  `approved_at` datetime DEFAULT NULL,
  `approved_by` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `security_alerts`
--

CREATE TABLE `security_alerts` (
  `id` int(11) NOT NULL,
  `alert_type` varchar(50) DEFAULT NULL,
  `message` text DEFAULT NULL,
  `severity` enum('low','medium','high') DEFAULT 'medium',
  `is_read` tinyint(1) DEFAULT 0,
  `alert_time` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `security_alerts`
--

INSERT INTO `security_alerts` (`id`, `alert_type`, `message`, `severity`, `is_read`, `alert_time`) VALUES
(1, 'new_ip', 'New login from IP: 192.168.1.122', 'medium', 1, '2026-03-02 22:29:48'),
(2, 'new_ip', 'New login from IP: 192.168.1.200', 'medium', 1, '2026-03-02 22:30:08'),
(3, 'new_ip', 'New login from IP: 192.168.1.189', 'medium', 1, '2026-03-02 22:32:15'),
(4, 'rapid_login', 'Multiple logins in short period', 'high', 1, '2026-03-02 22:32:15'),
(5, 'new_ip', 'New login from IP: 192.168.1.116', 'medium', 1, '2026-03-02 22:32:45'),
(6, 'rapid_login', 'Multiple logins in short period', 'high', 1, '2026-03-02 22:32:45'),
(7, 'new_ip', 'New login from IP: 192.168.1.146', 'medium', 1, '2026-03-02 22:33:04'),
(8, 'rapid_login', 'Multiple logins in short period', 'high', 1, '2026-03-02 22:33:04'),
(9, 'tampering', '🚨 Tampering detected in tbl_booking (ID: 20)', 'high', 1, '2026-03-02 23:20:46'),
(10, 'tampering', '🚨 Tampering detected in tbl_booking (ID: 20)', 'high', 1, '2026-03-02 23:20:56'),
(11, 'tampering', '🚨 Tampering detected in tbl_booking (ID: 20)', 'high', 1, '2026-03-02 23:21:01'),
(12, 'tampering', '🚨 Tampering detected in tbl_booking (ID: 20)', 'high', 1, '2026-03-02 23:21:01'),
(13, 'tampering', '🚨 Tampering detected in tbl_booking (ID: 20)', 'high', 1, '2026-03-02 23:21:04'),
(14, 'tampering', '🚨 Tampering detected in tbl_booking (ID: 20)', 'high', 1, '2026-03-02 23:21:09'),
(15, 'tampering', '🚨 Tampering detected in tbl_booking (ID: 20)', 'high', 1, '2026-03-02 23:21:09'),
(16, 'tampering', '🚨 Tampering detected in tbl_booking (ID: 20)', 'high', 1, '2026-03-02 23:21:10'),
(17, 'tampering', '🚨 Tampering detected in tbl_booking (ID: 20)', 'high', 1, '2026-03-02 23:21:14'),
(18, 'tampering', '🚨 Tampering detected in tbl_booking (ID: 20)', 'high', 1, '2026-03-02 23:21:47'),
(19, 'tampering', '🚨 Tampering detected in tbl_booking (ID: 20)', 'high', 1, '2026-03-02 23:21:47'),
(20, 'tampering', '🚨 Tampering detected in tbl_booking (ID: 20)', 'high', 1, '2026-03-02 23:23:53'),
(21, 'tampering', '🚨 Tampering detected in tbl_booking (ID: 20)', 'high', 1, '2026-03-02 23:23:53'),
(22, 'tampering', '🚨 Tampering detected in tbl_booking (ID: 20)', 'high', 1, '2026-03-02 23:24:02'),
(23, 'tampering', '🚨 Tampering detected in tbl_booking (ID: 21)', 'high', 1, '2026-03-02 23:24:02'),
(24, 'tampering', '🚨 Tampering detected in tbl_booking (ID: 20)', 'high', 1, '2026-03-02 23:24:08'),
(25, 'tampering', '🚨 Tampering detected in tbl_booking (ID: 21)', 'high', 1, '2026-03-02 23:24:08'),
(26, 'tampering', '🚨 Tampering detected in tbl_booking (ID: 20)', 'high', 1, '2026-03-02 23:24:09'),
(27, 'tampering', '🚨 Tampering detected in tbl_booking (ID: 21)', 'high', 1, '2026-03-02 23:24:09'),
(28, 'tampering', '🚨 Tampering detected in tbl_booking (ID: 20)', 'high', 1, '2026-03-02 23:24:09'),
(29, 'tampering', '🚨 Tampering detected in tbl_booking (ID: 21)', 'high', 1, '2026-03-02 23:24:09'),
(30, 'tampering', '🚨 Tampering detected in tbl_booking (ID: 20)', 'high', 1, '2026-03-02 23:24:14'),
(31, 'tampering', '🚨 Tampering detected in tbl_booking (ID: 21)', 'high', 1, '2026-03-02 23:24:14'),
(32, 'tampering', '🚨 Tampering detected in tbl_booking (ID: 20)', 'high', 1, '2026-03-02 23:24:26'),
(33, 'tampering', '🚨 Tampering detected in tbl_booking (ID: 21)', 'high', 1, '2026-03-02 23:24:26'),
(34, 'tampering', '🚨 Tampering detected in tbl_booking (ID: 20)', 'high', 1, '2026-03-02 23:24:33'),
(35, 'tampering', '🚨 Tampering detected in tbl_booking (ID: 21)', 'high', 1, '2026-03-02 23:24:33'),
(36, 'tampering', '🚨 Tampering detected in tbl_booking (ID: 20)', 'high', 1, '2026-03-02 23:24:33'),
(37, 'tampering', '🚨 Tampering detected in tbl_booking (ID: 21)', 'high', 1, '2026-03-02 23:24:33'),
(38, 'tampering', '🚨 Tampering detected in tbl_booking (ID: 20)', 'high', 1, '2026-03-02 23:24:38'),
(39, 'tampering', '🚨 Tampering detected in tbl_booking (ID: 21)', 'high', 1, '2026-03-02 23:24:38'),
(40, 'tampering', '🚨 Tampering detected in tbl_booking (ID: 20)', 'high', 1, '2026-03-02 23:24:41'),
(41, 'tampering', '🚨 Tampering detected in tbl_booking (ID: 21)', 'high', 1, '2026-03-02 23:24:41'),
(42, 'tampering', '🚨 Tampering detected in tbl_booking (ID: 20)', 'high', 1, '2026-03-02 23:24:44'),
(43, 'tampering', '🚨 Tampering detected in tbl_booking (ID: 21)', 'high', 1, '2026-03-02 23:24:44'),
(44, 'new_ip', 'New login from IP: 192.168.1.119', 'medium', 1, '2026-03-02 23:25:45'),
(45, 'tampering', '🚨 Tampering detected in tbl_booking (ID: 20)', 'high', 1, '2026-03-02 23:25:53'),
(46, 'tampering', '🚨 Tampering detected in tbl_booking (ID: 21)', 'high', 1, '2026-03-02 23:25:53'),
(47, 'tampering', '🚨 Tampering detected in tbl_booking (ID: 20)', 'high', 1, '2026-03-02 23:26:19'),
(48, 'tampering', '🚨 Tampering detected in tbl_booking (ID: 21)', 'high', 1, '2026-03-02 23:26:19'),
(49, 'tampering', '🚨 Tampering detected in tbl_booking (ID: 20)', 'high', 1, '2026-03-02 23:26:24'),
(50, 'tampering', '🚨 Tampering detected in tbl_booking (ID: 21)', 'high', 1, '2026-03-02 23:26:24'),
(51, 'tampering', '🚨 Tampering detected in tbl_booking (ID: 20)', 'high', 1, '2026-03-02 23:27:18'),
(52, 'tampering', '🚨 Tampering detected in tbl_booking (ID: 21)', 'high', 1, '2026-03-02 23:27:18'),
(53, 'tampering', '🚨 Tampering detected in tbl_booking (ID: 20)', 'high', 1, '2026-03-02 23:27:29'),
(54, 'tampering', '🚨 Tampering detected in tbl_booking (ID: 21)', 'high', 1, '2026-03-02 23:27:29'),
(55, 'tampering', '🚨 Tampering detected in tbl_booking (ID: 20)', 'high', 1, '2026-03-02 23:27:41'),
(56, 'tampering', '🚨 Tampering detected in tbl_booking (ID: 21)', 'high', 1, '2026-03-02 23:27:41'),
(57, 'tampering', '🚨 Tampering detected in tbl_booking (ID: 20)', 'high', 1, '2026-03-02 23:27:44'),
(58, 'tampering', '🚨 Tampering detected in tbl_booking (ID: 21)', 'high', 1, '2026-03-02 23:27:44'),
(59, 'tampering', '🚨 Tampering detected in tbl_booking (ID: 20)', 'high', 1, '2026-03-02 23:27:44'),
(60, 'tampering', '🚨 Tampering detected in tbl_booking (ID: 21)', 'high', 1, '2026-03-02 23:27:44'),
(61, 'tampering', '🚨 Tampering detected in tbl_booking (ID: 20)', 'high', 1, '2026-03-02 23:27:53'),
(62, 'tampering', '🚨 Tampering detected in tbl_booking (ID: 21)', 'high', 1, '2026-03-02 23:27:53'),
(63, 'tampering', '🚨 Tampering detected in tbl_booking (ID: 20)', 'high', 1, '2026-03-02 23:29:34'),
(64, 'tampering', '🚨 Tampering detected in tbl_booking (ID: 21)', 'high', 1, '2026-03-02 23:29:34'),
(65, 'tampering', '🚨 Tampering detected in tbl_booking (ID: 20)', 'high', 1, '2026-03-02 23:31:25'),
(66, 'tampering', '🚨 Tampering detected in tbl_booking (ID: 21)', 'high', 1, '2026-03-02 23:31:25'),
(67, 'new_ip', 'New login from IP: ::1', 'medium', 0, '2026-03-02 23:37:38'),
(68, 'tampering', '🚨 Tampering detected in tbl_booking (ID: 20)', 'high', 1, '2026-03-02 23:37:38'),
(69, 'tampering', '🚨 Tampering detected in tbl_booking (ID: 21)', 'high', 1, '2026-03-02 23:37:38'),
(70, 'tampering', '🚨 Tampering detected in tbl_booking (ID: 20)', 'high', 1, '2026-03-02 23:40:37'),
(71, 'tampering', '🚨 Tampering detected in tbl_booking (ID: 21)', 'high', 1, '2026-03-02 23:40:37'),
(72, 'tampering', '🚨 Tampering detected in tbl_booking (ID: 20)', 'high', 1, '2026-03-02 23:41:03'),
(73, 'tampering', '🚨 Tampering detected in tbl_booking (ID: 21)', 'high', 1, '2026-03-02 23:41:03'),
(74, 'tampering', '🚨 Tampering detected in tbl_booking (ID: 20)', 'high', 1, '2026-03-02 23:41:45'),
(75, 'tampering', '🚨 Tampering detected in tbl_booking (ID: 21)', 'high', 1, '2026-03-02 23:41:45'),
(76, 'tampering', '🚨 Tampering detected in tbl_booking (ID: 20)', 'high', 1, '2026-03-02 23:43:45'),
(77, 'tampering', '🚨 Tampering detected in tbl_booking (ID: 21)', 'high', 1, '2026-03-02 23:43:45'),
(78, 'session_hijack', '🚨 Possible session hijacking detected!', 'high', 0, '2026-03-02 23:45:11'),
(79, 'tampering', '🚨 Tampering detected in tbl_booking (ID: 20)', 'high', 1, '2026-03-02 23:46:04'),
(80, 'tampering', '🚨 Tampering detected in tbl_booking (ID: 21)', 'high', 1, '2026-03-02 23:46:04'),
(81, 'tampering', '🚨 Tampering detected in tbl_booking (ID: 20)', 'high', 1, '2026-03-02 23:48:45'),
(82, 'tampering', '🚨 Tampering detected in tbl_booking (ID: 21)', 'high', 1, '2026-03-02 23:48:45'),
(83, 'tampering', '🚨 Tampering detected in tbl_booking (ID: 20)', 'high', 1, '2026-03-02 23:50:26'),
(84, 'tampering', '🚨 Tampering detected in tbl_booking (ID: 21)', 'high', 1, '2026-03-02 23:50:26'),
(85, 'tampering', '🚨 Tampering detected in tbl_booking (ID: 20)', 'high', 1, '2026-03-02 23:51:05'),
(86, 'tampering', '🚨 Tampering detected in tbl_booking (ID: 21)', 'high', 1, '2026-03-02 23:51:05'),
(87, 'tampering', '🚨 Tampering detected in tbl_booking (ID: 20)', 'high', 1, '2026-03-02 23:55:27'),
(88, 'tampering', '🚨 Tampering detected in tbl_booking (ID: 21)', 'high', 1, '2026-03-02 23:55:27'),
(89, 'tampering', '🚨 Tampering detected in tbl_booking (ID: 20)', 'high', 1, '2026-03-02 23:56:06'),
(90, 'tampering', '🚨 Tampering detected in tbl_booking (ID: 21)', 'high', 1, '2026-03-02 23:56:06'),
(91, 'anomaly', 'Unusual activity: 20 changes in 1 minute', 'high', 0, '2026-03-02 23:59:20'),
(92, 'anomaly', 'Unusual activity: 21 changes in 1 minute', 'high', 0, '2026-03-02 23:59:20'),
(93, 'anomaly', 'Unusual activity: 22 changes in 1 minute', 'high', 0, '2026-03-02 23:59:20'),
(94, 'anomaly', 'Unusual activity: 23 changes in 1 minute', 'high', 0, '2026-03-02 23:59:20'),
(95, 'anomaly', 'Unusual activity: 24 changes in 1 minute', 'high', 0, '2026-03-02 23:59:20'),
(96, 'anomaly', 'Unusual activity: 25 changes in 1 minute', 'high', 0, '2026-03-02 23:59:20'),
(97, 'anomaly', 'Unusual activity: 26 changes in 1 minute', 'high', 0, '2026-03-02 23:59:20'),
(98, 'anomaly', 'Unusual activity: 27 changes in 1 minute', 'high', 0, '2026-03-02 23:59:20'),
(99, 'anomaly', 'Unusual activity: 28 changes in 1 minute', 'high', 0, '2026-03-02 23:59:20'),
(100, 'anomaly', 'Unusual activity: 29 changes in 1 minute', 'high', 0, '2026-03-02 23:59:41'),
(101, 'tampering', '🚨 Tampering detected in tbl_booking (ID: 20)', 'high', 1, '2026-03-02 23:59:50'),
(102, 'tampering', '🚨 Tampering detected in tbl_booking (ID: 21)', 'high', 1, '2026-03-02 23:59:50'),
(103, 'tampering', '🚨 Tampering detected in tbl_booking (ID: 20)', 'high', 1, '2026-03-02 23:59:54'),
(104, 'tampering', '🚨 Tampering detected in tbl_booking (ID: 21)', 'high', 1, '2026-03-02 23:59:54'),
(105, 'tampering', '🚨 Tampering detected in tbl_booking (ID: 20)', 'high', 1, '2026-03-02 23:59:59'),
(106, 'tampering', '🚨 Tampering detected in tbl_booking (ID: 21)', 'high', 1, '2026-03-02 23:59:59'),
(107, 'tampering', '🚨 Tampering detected in tbl_booking (ID: 20)', 'high', 1, '2026-03-03 00:00:02'),
(108, 'tampering', '🚨 Tampering detected in tbl_booking (ID: 21)', 'high', 1, '2026-03-03 00:00:02'),
(109, 'tampering', '🚨 Tampering detected in tbl_booking (ID: 20)', 'high', 1, '2026-03-03 00:00:28'),
(110, 'tampering', '🚨 Tampering detected in tbl_booking (ID: 21)', 'high', 1, '2026-03-03 00:00:28'),
(111, 'tampering', '🚨 Tampering detected in tbl_booking (ID: 20)', 'high', 1, '2026-03-03 00:05:03'),
(112, 'tampering', '🚨 Tampering detected in tbl_booking (ID: 21)', 'high', 1, '2026-03-03 00:05:03'),
(113, 'tampering', '🚨 Tampering detected in tbl_booking (ID: 20)', 'high', 1, '2026-03-03 00:05:29'),
(114, 'tampering', '🚨 Tampering detected in tbl_booking (ID: 21)', 'high', 1, '2026-03-03 00:05:29'),
(115, 'tampering', '🚨 Tampering detected in tbl_booking (ID: 20)', 'high', 1, '2026-03-03 00:10:04'),
(116, 'tampering', '🚨 Tampering detected in tbl_booking (ID: 21)', 'high', 1, '2026-03-03 00:10:04'),
(117, 'tampering', '🚨 Tampering detected in tbl_booking (ID: 20)', 'high', 1, '2026-03-03 00:10:30'),
(118, 'tampering', '🚨 Tampering detected in tbl_booking (ID: 21)', 'high', 1, '2026-03-03 00:10:30'),
(119, 'tampering', '🚨 Tampering detected in tbl_booking (ID: 20)', 'high', 1, '2026-03-03 00:15:05'),
(120, 'tampering', '🚨 Tampering detected in tbl_booking (ID: 21)', 'high', 1, '2026-03-03 00:15:05'),
(121, 'tampering', '🚨 Tampering detected in tbl_booking (ID: 20)', 'high', 1, '2026-03-03 00:15:31'),
(122, 'tampering', '🚨 Tampering detected in tbl_booking (ID: 21)', 'high', 1, '2026-03-03 00:15:31'),
(123, 'tampering', '🚨 Tampering detected in tbl_booking (ID: 20)', 'high', 1, '2026-03-03 00:20:06'),
(124, 'tampering', '🚨 Tampering detected in tbl_booking (ID: 21)', 'high', 1, '2026-03-03 00:20:06'),
(125, 'tampering', '🚨 Tampering detected in tbl_booking (ID: 20)', 'high', 1, '2026-03-03 00:20:32'),
(126, 'tampering', '🚨 Tampering detected in tbl_booking (ID: 21)', 'high', 1, '2026-03-03 00:20:32'),
(127, 'tampering', '🚨 Tampering detected in tbl_booking (ID: 20)', 'high', 1, '2026-03-03 00:25:07'),
(128, 'tampering', '🚨 Tampering detected in tbl_booking (ID: 21)', 'high', 1, '2026-03-03 00:25:07'),
(129, 'tampering', '🚨 Tampering detected in tbl_booking (ID: 20)', 'high', 1, '2026-03-03 00:25:33'),
(130, 'tampering', '🚨 Tampering detected in tbl_booking (ID: 21)', 'high', 1, '2026-03-03 00:25:33'),
(131, 'tampering', '🚨 Tampering detected in tbl_booking (ID: 20)', 'high', 1, '2026-03-03 00:30:08'),
(132, 'tampering', '🚨 Tampering detected in tbl_booking (ID: 21)', 'high', 1, '2026-03-03 00:30:08'),
(133, 'tampering', '🚨 Tampering detected in tbl_booking (ID: 20)', 'high', 1, '2026-03-03 00:30:34'),
(134, 'tampering', '🚨 Tampering detected in tbl_booking (ID: 21)', 'high', 1, '2026-03-03 00:30:34'),
(135, 'tampering', '🚨 Tampering detected in tbl_booking (ID: 20)', 'high', 1, '2026-03-03 00:35:09'),
(136, 'tampering', '🚨 Tampering detected in tbl_booking (ID: 21)', 'high', 1, '2026-03-03 00:35:09'),
(137, 'tampering', '🚨 Tampering detected in tbl_booking (ID: 20)', 'high', 1, '2026-03-03 00:35:35'),
(138, 'tampering', '🚨 Tampering detected in tbl_booking (ID: 21)', 'high', 1, '2026-03-03 00:35:35'),
(139, 'tampering', '🚨 Tampering detected in tbl_booking (ID: 20)', 'high', 1, '2026-03-03 00:40:10'),
(140, 'tampering', '🚨 Tampering detected in tbl_booking (ID: 21)', 'high', 1, '2026-03-03 00:40:10'),
(141, 'tampering', '🚨 Tampering detected in tbl_booking (ID: 20)', 'high', 1, '2026-03-03 00:40:36'),
(142, 'tampering', '🚨 Tampering detected in tbl_booking (ID: 21)', 'high', 1, '2026-03-03 00:40:36'),
(143, 'tampering', '🚨 Tampering detected in tbl_booking (ID: 20)', 'high', 1, '2026-03-03 00:45:11'),
(144, 'tampering', '🚨 Tampering detected in tbl_booking (ID: 21)', 'high', 1, '2026-03-03 00:45:11'),
(145, 'tampering', '🚨 Tampering detected in tbl_booking (ID: 20)', 'high', 1, '2026-03-03 00:45:37'),
(146, 'tampering', '🚨 Tampering detected in tbl_booking (ID: 21)', 'high', 1, '2026-03-03 00:45:37'),
(147, 'tampering', '🚨 Tampering detected in tbl_booking (ID: 20)', 'high', 1, '2026-03-03 00:48:35'),
(148, 'tampering', '🚨 Tampering detected in tbl_booking (ID: 21)', 'high', 1, '2026-03-03 00:48:35'),
(149, 'tampering', '🚨 Tampering detected in tbl_booking (ID: 20)', 'high', 1, '2026-03-03 00:48:37'),
(150, 'tampering', '🚨 Tampering detected in tbl_booking (ID: 21)', 'high', 1, '2026-03-03 00:48:37'),
(151, 'tampering', '🚨 Tampering detected in tbl_booking (ID: 20)', 'high', 1, '2026-03-03 00:48:56'),
(152, 'tampering', '🚨 Tampering detected in tbl_booking (ID: 21)', 'high', 1, '2026-03-03 00:48:56'),
(153, 'tampering', '🚨 Tampering detected in tbl_booking (ID: 20)', 'high', 1, '2026-03-03 00:48:58'),
(154, 'tampering', '🚨 Tampering detected in tbl_booking (ID: 21)', 'high', 1, '2026-03-03 00:48:58'),
(155, 'session_hijack', '🚨 Possible session hijacking detected!', 'high', 0, '2026-03-03 00:49:01'),
(156, 'tampering', '🚨 Tampering detected in tbl_booking (ID: 20)', 'high', 1, '2026-03-03 00:49:07'),
(157, 'tampering', '🚨 Tampering detected in tbl_booking (ID: 21)', 'high', 1, '2026-03-03 00:49:07'),
(158, 'session_hijack', '🚨 Possible session hijacking detected!', 'high', 0, '2026-03-03 00:49:11'),
(159, 'tampering', '🚨 Tampering detected in tbl_booking (ID: 20)', 'high', 1, '2026-03-03 00:49:14'),
(160, 'tampering', '🚨 Tampering detected in tbl_booking (ID: 21)', 'high', 1, '2026-03-03 00:49:14'),
(161, 'tampering', '🚨 Tampering detected in tbl_booking (ID: 20)', 'high', 1, '2026-03-03 00:49:15'),
(162, 'tampering', '🚨 Tampering detected in tbl_booking (ID: 21)', 'high', 1, '2026-03-03 00:49:15'),
(163, 'tampering', '🚨 Tampering detected in tbl_booking (ID: 20)', 'high', 1, '2026-03-03 00:49:20'),
(164, 'tampering', '🚨 Tampering detected in tbl_booking (ID: 21)', 'high', 1, '2026-03-03 00:49:20'),
(165, 'tampering', '🚨 Tampering detected in tbl_booking (ID: 20)', 'high', 1, '2026-03-03 00:49:25'),
(166, 'tampering', '🚨 Tampering detected in tbl_booking (ID: 21)', 'high', 1, '2026-03-03 00:49:25'),
(167, 'tampering', '🚨 Tampering detected in tbl_booking (ID: 20)', 'high', 1, '2026-03-03 00:49:34'),
(168, 'tampering', '🚨 Tampering detected in tbl_booking (ID: 21)', 'high', 1, '2026-03-03 00:49:34'),
(169, 'tampering', '🚨 Tampering detected in tbl_booking (ID: 20)', 'high', 1, '2026-03-03 00:49:38'),
(170, 'tampering', '🚨 Tampering detected in tbl_booking (ID: 21)', 'high', 1, '2026-03-03 00:49:38'),
(171, 'tampering', '🚨 Tampering detected in tbl_booking (ID: 20)', 'high', 1, '2026-03-03 00:49:39'),
(172, 'tampering', '🚨 Tampering detected in tbl_booking (ID: 21)', 'high', 1, '2026-03-03 00:49:39'),
(173, 'anomaly', 'Mass deletion detected: 10 records deleted in 5 minutes', 'high', 0, '2026-03-03 00:50:01'),
(174, 'anomaly', 'Mass deletion detected: 11 records deleted in 5 minutes', 'high', 0, '2026-03-03 00:50:01'),
(175, 'anomaly', 'Mass deletion detected: 12 records deleted in 5 minutes', 'high', 0, '2026-03-03 00:50:01'),
(176, 'tampering', '🚨 Tampering detected in tbl_booking (ID: 20)', 'high', 1, '2026-03-03 00:50:07'),
(177, 'tampering', '🚨 Tampering detected in tbl_booking (ID: 21)', 'high', 1, '2026-03-03 00:50:07'),
(178, 'tampering', '🚨 Tampering detected in tbl_booking (ID: 20)', 'high', 1, '2026-03-03 00:50:39'),
(179, 'tampering', '🚨 Tampering detected in tbl_booking (ID: 21)', 'high', 1, '2026-03-03 00:50:39'),
(180, 'tampering', '🚨 Tampering detected in tbl_booking (ID: 20)', 'high', 1, '2026-03-03 00:50:39'),
(181, 'tampering', '🚨 Tampering detected in tbl_booking (ID: 21)', 'high', 1, '2026-03-03 00:50:39'),
(182, 'tampering', '🚨 Tampering detected in tbl_booking (ID: 20)', 'high', 1, '2026-03-03 00:50:49'),
(183, 'tampering', '🚨 Tampering detected in tbl_booking (ID: 21)', 'high', 1, '2026-03-03 00:50:49'),
(184, 'tampering', '🚨 Tampering detected in tbl_booking (ID: 20)', 'high', 1, '2026-03-03 00:50:49'),
(185, 'tampering', '🚨 Tampering detected in tbl_booking (ID: 21)', 'high', 1, '2026-03-03 00:50:49'),
(186, 'tampering', '🚨 Tampering detected in tbl_booking (ID: 20)', 'high', 1, '2026-03-03 00:52:13'),
(187, 'tampering', '🚨 Tampering detected in tbl_booking (ID: 21)', 'high', 1, '2026-03-03 00:52:13'),
(188, 'tampering', '🚨 Tampering detected in tbl_booking (ID: 20)', 'high', 1, '2026-03-03 00:52:20'),
(189, 'tampering', '🚨 Tampering detected in tbl_booking (ID: 21)', 'high', 1, '2026-03-03 00:52:20'),
(190, 'tampering', '🚨 Tampering detected in tbl_booking (ID: 20)', 'high', 1, '2026-03-03 00:52:21'),
(191, 'tampering', '🚨 Tampering detected in tbl_booking (ID: 21)', 'high', 1, '2026-03-03 00:52:21'),
(192, 'tampering', '🚨 Tampering detected in tbl_booking (ID: 20)', 'high', 1, '2026-03-03 00:52:22'),
(193, 'tampering', '🚨 Tampering detected in tbl_booking (ID: 21)', 'high', 1, '2026-03-03 00:52:22'),
(194, 'tampering', '🚨 Tampering detected in tbl_booking (ID: 20)', 'high', 1, '2026-03-03 00:52:23'),
(195, 'tampering', '🚨 Tampering detected in tbl_booking (ID: 21)', 'high', 1, '2026-03-03 00:52:23'),
(196, 'tampering', '🚨 Tampering detected in tbl_booking (ID: 20)', 'high', 1, '2026-03-03 00:52:23'),
(197, 'tampering', '🚨 Tampering detected in tbl_booking (ID: 21)', 'high', 1, '2026-03-03 00:52:23'),
(198, 'tampering', '🚨 Tampering detected in tbl_booking (ID: 20)', 'high', 1, '2026-03-03 00:52:25'),
(199, 'tampering', '🚨 Tampering detected in tbl_booking (ID: 21)', 'high', 1, '2026-03-03 00:52:25'),
(200, 'tampering', '🚨 Tampering detected in tbl_booking (ID: 20)', 'high', 1, '2026-03-03 00:52:32'),
(201, 'tampering', '🚨 Tampering detected in tbl_booking (ID: 21)', 'high', 1, '2026-03-03 00:52:32'),
(202, 'session_hijack', '🚨 Possible session hijacking detected!', 'high', 0, '2026-03-03 00:56:53'),
(203, 'session_hijack', '🚨 Possible session hijacking detected!', 'high', 0, '2026-03-03 00:56:54');

-- --------------------------------------------------------

--
-- Table structure for table `session_hijack_logs`
--

CREATE TABLE `session_hijack_logs` (
  `id` int(11) NOT NULL,
  `admin_id` int(11) DEFAULT NULL,
  `attempted_ip` varchar(45) DEFAULT NULL,
  `attempted_ua` text DEFAULT NULL,
  `detected_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `session_hijack_logs`
--

INSERT INTO `session_hijack_logs` (`id`, `admin_id`, `attempted_ip`, `attempted_ua`, `detected_at`) VALUES
(1, 1, '::1', 'Fake Browser 1.0', '2026-03-02 23:45:11'),
(2, 1, '::1', 'Fake Browser 1.0', '2026-03-03 00:49:01'),
(3, 1, '::1', 'Fake Browser 1.0', '2026-03-03 00:49:11'),
(4, 1, '::1', 'Fake Browser 1.0', '2026-03-03 00:56:53'),
(5, 1, '::1', 'Fake Browser 1.0', '2026-03-03 00:56:54');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_booking`
--

CREATE TABLE `tbl_booking` (
  `id` int(11) NOT NULL,
  `booking_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `emailid` varchar(255) NOT NULL,
  `mobile` varchar(10) NOT NULL,
  `booking_date` date NOT NULL,
  `booking_time` time NOT NULL,
  `adults` smallint(6) NOT NULL,
  `childrens` smallint(6) NOT NULL,
  `special_request` text DEFAULT NULL,
  `booking_status` tinyint(4) NOT NULL DEFAULT 0 COMMENT '0=New Booking; 1=Confirmed; 2=Rejected;',
  `integrity_hash` varchar(64) DEFAULT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `tbl_booking`
--

INSERT INTO `tbl_booking` (`id`, `booking_id`, `name`, `emailid`, `mobile`, `booking_date`, `booking_time`, `adults`, `childrens`, `special_request`, `booking_status`, `integrity_hash`, `ip_address`, `created_at`) VALUES
(1, 1001, 'John Smith', 'john.smith@email.com', '9876543210', '2026-03-04', '19:30:00', 2, 0, 'Anniversary celebration - prefer window table', 1, NULL, NULL, '2026-03-01 17:09:05'),
(2, 1002, 'Sarah Johnson', 'sarah.j@email.com', '9876543211', '2026-03-05', '20:00:00', 4, 2, 'Kids need high chairs', 1, NULL, NULL, '2026-03-01 17:09:05'),
(3, 1003, 'Michael Brown', 'michael.b@email.com', '9876543212', '2026-03-03', '18:30:00', 2, 0, NULL, 1, NULL, NULL, '2026-03-01 17:09:05'),
(4, 1004, 'Emily Davis', 'emily.d@email.com', '9876543213', '2026-03-06', '19:00:00', 3, 1, 'Birthday cake arrangement needed', 1, NULL, NULL, '2026-03-01 17:09:05'),
(5, 1005, 'David Wilson', 'david.w@email.com', '9876543214', '2026-03-07', '20:30:00', 6, 0, 'Office team dinner - prefer private area', 1, NULL, NULL, '2026-03-01 17:09:05'),
(6, 1006, 'Lisa Anderson', 'lisa.a@email.com', '9876543215', '2026-03-04', '19:00:00', 2, 0, 'Window seat preferred', 0, NULL, NULL, '2026-03-01 17:09:05'),
(7, 1007, 'Robert Taylor', 'robert.t@email.com', '9876543216', '2026-03-05', '20:00:00', 4, 2, NULL, 0, NULL, NULL, '2026-03-01 17:09:05'),
(8, 1008, 'Jennifer Martin', 'jennifer.m@email.com', '9876543217', '2026-03-08', '19:30:00', 5, 0, 'Allergic to nuts - please ensure kitchen is aware', 2, NULL, NULL, '2026-03-02 17:00:26'),
(9, 1009, 'William Lee', 'william.l@email.com', '9876543218', '2026-03-03', '20:00:00', 2, 0, NULL, 2, NULL, NULL, '2026-03-01 17:09:05'),
(10, 1010, 'Maria Garcia', 'maria.g@email.com', '9876543219', '2026-03-09', '19:00:00', 3, 1, 'Vegetarian options needed', 0, NULL, NULL, '2026-03-01 17:09:05'),
(11, 1011, 'James Wilson', 'james.w@email.com', '9876543220', '2026-03-10', '18:30:00', 8, 0, 'Business meeting - need quiet area', 0, NULL, NULL, '2026-03-01 17:09:05'),
(12, 1012, 'Patricia Moore', 'patricia.m@email.com', '9876543221', '2026-03-11', '20:30:00', 2, 0, 'Anniversary dinner', 1, NULL, NULL, '2026-03-01 17:09:05'),
(13, 1013, 'Thomas Clark', 'thomas.c@email.com', '9876543222', '2026-03-12', '19:00:00', 4, 0, NULL, 0, NULL, NULL, '2026-03-01 17:09:05'),
(14, 1014, 'Nancy Rodriguez', 'nancy.r@email.com', '9876543223', '2026-03-13', '20:00:00', 6, 2, 'Birthday party - need cake', 0, NULL, NULL, '2026-03-01 17:09:05'),
(15, 1015, 'Kevin White', 'kevin.w@email.com', '9876543224', '2026-03-14', '19:30:00', 2, 0, NULL, 0, NULL, NULL, '2026-03-01 17:09:05'),
(16, 1016, 'Agnes', 'agneslithe@gmail.com', '9153049274', '2026-03-02', '17:16:00', 6, 3, NULL, 0, NULL, '::1', '2026-03-02 09:16:25'),
(17, 19787506, 'Agnes Micheals', 'agneslithe@gmail.com', '6175550102', '2026-03-02', '20:54:00', 3, 0, NULL, 0, NULL, NULL, '2026-03-02 12:53:25'),
(18, 74946420, 'Margaret Quilley', 'margaret@gmail.com', '9153049274', '2026-03-02', '21:15:00', 2, 1, NULL, 0, NULL, '::1', '2026-03-02 13:14:36'),
(19, 23567125, 'Alicia Silverstone', 'alicia@gmail.com', '6175550106', '2026-03-02', '21:18:00', 1, 2, NULL, 0, NULL, '::1', '2026-03-02 13:15:05'),
(20, 49799590, 'Test Customer 30 (TAMPERED)', 'test44@email.com', '9876548688', '2026-03-02', '19:00:00', 2, 0, NULL, 0, '9a26b2e2a30db52f30418b84c68109b4d20fc0959e02c113a0e8c02b0625785f', '127.0.0.1', '2026-03-02 15:20:56'),
(21, 56078503, 'Test Customer 31 (TAMPERED)', 'test58@email.com', '9876580521', '2026-03-02', '19:00:00', 2, 0, NULL, 0, 'ba25b1940eeeb3fe07ad52a60a0810438a3f95eff1516ec6210d2e882641b5a6', '127.0.0.1', '2026-03-02 15:24:08');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_booking_status`
--

CREATE TABLE `tbl_booking_status` (
  `id` int(11) NOT NULL,
  `booking_id` int(11) NOT NULL,
  `table_no` varchar(255) NOT NULL,
  `booking_status` varchar(255) NOT NULL COMMENT '1=Confirmed; 2=Rejected;',
  `remarks` text NOT NULL,
  `updated_by` varchar(100) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `tbl_booking_status`
--

INSERT INTO `tbl_booking_status` (`id`, `booking_id`, `table_no`, `booking_status`, `remarks`, `updated_by`, `created_at`) VALUES
(1, 1001, 'Table 2', '1', 'Confirmed - Window table assigned', 'admin', '2026-03-01 17:09:05'),
(2, 1002, 'Table 7', '1', 'Confirmed - VIP section with high chairs', 'admin', '2026-03-01 17:09:05'),
(3, 1003, 'Table 1', '1', 'Confirmed - Regular customer', 'admin', '2026-03-01 17:09:05'),
(4, 1004, 'Table 4', '1', 'Confirmed - Birthday arrangement noted', 'admin', '2026-03-01 17:09:05'),
(5, 1005, 'Table 6', '1', 'Confirmed - Private area reserved', 'admin', '2026-03-01 17:09:05'),
(6, 1009, 'Table 3', '2', 'Rejected - Restaurant fully booked', 'admin', '2026-03-01 17:09:05'),
(7, 1012, 'Table 5', '1', 'Confirmed - Anniversary special', 'admin', '2026-03-01 17:09:05'),
(8, 1008, '', '2', '', NULL, '2026-03-02 17:00:26');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_contact`
--

CREATE TABLE `tbl_contact` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `subject` varchar(255) NOT NULL,
  `message` text NOT NULL,
  `status` tinyint(4) DEFAULT 0 COMMENT '0=Unread, 1=Read',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `tbl_contact`
--

INSERT INTO `tbl_contact` (`id`, `name`, `email`, `subject`, `message`, `status`, `created_at`) VALUES
(1, 'James Wilson', 'james.w@email.com', 'Birthday Party Inquiry', 'I would like to book for a birthday party of 15 people on the 25th. Do you have private dining options?', 0, '2026-03-01 17:09:05'),
(2, 'Patricia Moore', 'patricia.m@email.com', 'Feedback - Excellent Service', 'The food was amazing and service was excellent! Will definitely come again.', 1, '2026-03-01 17:09:05'),
(3, 'Thomas Clark', 'thomas.c@email.com', 'Vegetarian Menu Inquiry', 'Do you offer vegan options? I have guests with dietary restrictions.', 0, '2026-03-01 17:09:05'),
(4, 'Nancy Rodriguez', 'nancy.r@email.com', 'Reservation Change Request', 'I need to change my reservation from 7:30 PM to 8:30 PM on March 20th.', 1, '2026-03-01 17:09:05'),
(5, 'Kevin White', 'kevin.w@email.com', 'Catering Services', 'Do you provide catering for corporate events? We have an office party of 50 people.', 0, '2026-03-01 17:09:05'),
(6, 'Lisa Anderson', 'lisa.a@email.com', 'Lost Item', 'I think I left my scarf at Table 5 last night. Please check.', 1, '2026-03-01 17:09:05'),
(7, 'Robert Taylor', 'robert.t@email.com', 'Menu Suggestion', 'Would love to see more seafood options on the menu.', 0, '2026-03-01 17:09:05');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_table`
--

CREATE TABLE `tbl_table` (
  `id` int(11) NOT NULL,
  `table_no` varchar(255) NOT NULL,
  `integrity_hash` varchar(64) DEFAULT NULL,
  `capacity` int(11) DEFAULT NULL,
  `location` varchar(100) DEFAULT NULL,
  `status` tinyint(4) DEFAULT 1 COMMENT '1=Available, 0=Unavailable',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `tbl_table`
--

INSERT INTO `tbl_table` (`id`, `table_no`, `integrity_hash`, `capacity`, `location`, `status`, `created_at`) VALUES
(1, 'Table 1', NULL, 2, 'Window Side', 0, '2026-03-02 08:05:07'),
(2, 'Table 2', NULL, 2, 'Window Side', 1, '2026-03-01 17:09:05'),
(3, 'Table 3', NULL, 4, 'Main Hall', 1, '2026-03-01 17:09:05'),
(4, 'Table 4', NULL, 4, 'Main Hall', 1, '2026-03-01 17:09:05'),
(5, 'Table 5', NULL, 6, 'Main Hall', 1, '2026-03-01 17:09:05'),
(6, 'Table 6', NULL, 6, 'Main Hall', 1, '2026-03-01 17:09:05'),
(7, 'Table 7', NULL, 8, 'VIP Section', 1, '2026-03-01 17:09:05'),
(8, 'Table 8', NULL, 8, 'VIP Section', 1, '2026-03-01 17:09:05'),
(9, 'Table 9', NULL, 4, 'Outdoor', 1, '2026-03-01 17:09:05'),
(10, 'Table 10', NULL, 4, 'Outdoor', 1, '2026-03-01 17:09:05'),
(11, 'Table 11', NULL, 2, 'Balcony', 1, '2026-03-01 17:09:05'),
(12, 'Table 12', NULL, 2, 'Balcony', 1, '2026-03-01 17:09:05'),
(13, 'Table 13', NULL, 10, 'Private Room', 1, '2026-03-01 17:09:05'),
(14, 'Table 14', NULL, 10, 'Private Room', 1, '2026-03-01 17:09:05'),
(15, 'Table 15', NULL, 12, 'Party Hall', 1, '2026-03-01 17:09:05'),
(16, 'Table 1', NULL, 2, NULL, 1, '2026-03-02 07:13:18'),
(17, 'Table 2', NULL, 2, NULL, 1, '2026-03-02 07:13:18'),
(18, 'Table 3', NULL, 4, NULL, 1, '2026-03-02 07:13:18'),
(19, 'Table 4', NULL, 4, NULL, 1, '2026-03-02 07:13:18'),
(20, 'Table 5', NULL, 6, NULL, 1, '2026-03-02 07:13:18'),
(21, 'Table 6', NULL, 6, NULL, 1, '2026-03-02 07:13:18'),
(22, 'Table 7', NULL, 8, NULL, 1, '2026-03-02 07:13:18'),
(23, 'Table 8', NULL, 8, NULL, 1, '2026-03-02 07:13:18');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(21) NOT NULL,
  `username` varchar(21) NOT NULL,
  `firstName` varchar(21) NOT NULL,
  `lastName` varchar(21) NOT NULL,
  `email` varchar(35) NOT NULL,
  `phone` bigint(20) NOT NULL,
  `userType` enum('0','1') NOT NULL DEFAULT '0' COMMENT '0=user, 1=admin',
  `password` varchar(255) NOT NULL,
  `integrity_hash` varchar(64) DEFAULT NULL,
  `joinDate` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=COMPACT;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `firstName`, `lastName`, `email`, `phone`, `userType`, `password`, `integrity_hash`, `joinDate`) VALUES
(1, 'admin', 'Admin', 'User', 'admin@localhost.local', 9990105028, '1', '$2y$10$RhReit4tS4ghp5ZlkyHfS.K1Nl//nlXZ8lvglm0oCMNMomALHJ4ti', NULL, '2026-03-02 01:09:05');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin_behavior`
--
ALTER TABLE `admin_behavior`
  ADD PRIMARY KEY (`id`),
  ADD KEY `admin_id` (`admin_id`),
  ADD KEY `ip_address` (`ip_address`);

--
-- Indexes for table `admin_login_history`
--
ALTER TABLE `admin_login_history`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `admin_sessions`
--
ALTER TABLE `admin_sessions`
  ADD PRIMARY KEY (`id`),
  ADD KEY `admin_id` (`admin_id`);

--
-- Indexes for table `anomaly_alerts`
--
ALTER TABLE `anomaly_alerts`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `audit_log`
--
ALTER TABLE `audit_log`
  ADD PRIMARY KEY (`id`),
  ADD KEY `admin_id` (`admin_id`),
  ADD KEY `change_time` (`change_time`);

--
-- Indexes for table `data_tampering_log`
--
ALTER TABLE `data_tampering_log`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `pending_approvals`
--
ALTER TABLE `pending_approvals`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `token` (`approval_token`);

--
-- Indexes for table `security_alerts`
--
ALTER TABLE `security_alerts`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `session_hijack_logs`
--
ALTER TABLE `session_hijack_logs`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_booking`
--
ALTER TABLE `tbl_booking`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_ip_time` (`ip_address`,`created_at`);

--
-- Indexes for table `tbl_booking_status`
--
ALTER TABLE `tbl_booking_status`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_contact`
--
ALTER TABLE `tbl_contact`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_table`
--
ALTER TABLE `tbl_table`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`) USING BTREE,
  ADD UNIQUE KEY `username` (`username`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin_behavior`
--
ALTER TABLE `admin_behavior`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=30;

--
-- AUTO_INCREMENT for table `admin_login_history`
--
ALTER TABLE `admin_login_history`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `admin_sessions`
--
ALTER TABLE `admin_sessions`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `anomaly_alerts`
--
ALTER TABLE `anomaly_alerts`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `audit_log`
--
ALTER TABLE `audit_log`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=43;

--
-- AUTO_INCREMENT for table `data_tampering_log`
--
ALTER TABLE `data_tampering_log`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=176;

--
-- AUTO_INCREMENT for table `pending_approvals`
--
ALTER TABLE `pending_approvals`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `security_alerts`
--
ALTER TABLE `security_alerts`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=204;

--
-- AUTO_INCREMENT for table `session_hijack_logs`
--
ALTER TABLE `session_hijack_logs`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `tbl_booking`
--
ALTER TABLE `tbl_booking`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- AUTO_INCREMENT for table `tbl_booking_status`
--
ALTER TABLE `tbl_booking_status`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `tbl_contact`
--
ALTER TABLE `tbl_contact`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `tbl_table`
--
ALTER TABLE `tbl_table`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(21) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
