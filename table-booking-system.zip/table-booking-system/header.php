<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <title>Kathi - Restaurant Table Booking</title>
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <meta content="" name="keywords">
    <meta content="" name="description">

    <!-- Favicon -->
    <link href="img/favicon.ico" rel="icon">

    <!-- Google Web Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Heebo:wght@400;500;600&family=Nunito:wght@600;700;800&family=Pacifico&display=swap" rel="stylesheet">

    <!-- Icon Font Stylesheet -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.0/css/all.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.4.1/font/bootstrap-icons.css" rel="stylesheet">

    <!-- Libraries Stylesheet -->
    <link href="lib/animate/animate.min.css" rel="stylesheet">
    <link href="lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet">
    <link href="lib/tempusdominus/css/tempusdominus-bootstrap-4.min.css" rel="stylesheet" />

    <!-- Customized Bootstrap Stylesheet -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
    <!-- Template Stylesheet -->
    <link href="css/style.css" rel="stylesheet">

    <style>
        .timeout-alert {
            position: fixed;
            top: 20px;
            right: 20px;
            z-index: 9999;
            min-width: 300px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.3);
            animation: slideIn 0.5s;
        }
        @keyframes slideIn {
            from {transform: translateX(100%);}
            to {transform: translateX(0);}
        }
    </style>
</head>

<body>
    <div class="container-xxl bg-white p-0">
        <!-- Navbar & Hero Start -->
        <div class="container-xxl position-relative p-0">
            <nav class="navbar navbar-expand-lg navbar-dark bg-dark px-4 px-lg-5 py-3 py-lg-0">
                <a href="index.php" class="navbar-brand p-0">
                    <h1 style="color:#FEA116 !important"; class="m-0"><i class="fa fa-utensils me-3"></i>Kathi</h1>
                </a>
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarCollapse">
                    <span class="fa fa-bars"></span>
                </button>
                <div class="collapse navbar-collapse" id="navbarCollapse">
                    <div class="navbar-nav ms-auto py-0 pe-4">
                        <a href="index.php" class="nav-item nav-link active">Home</a>
                        <a href="about.php" class="nav-item nav-link">About</a>
                        <a href="contact.php" class="nav-item nav-link">Contact</a>
                        <a href="#" class="nav-item nav-link" data-dismiss="modal" data-toggle="modal" data-target="#statusModal">Check Status</a>
                    </div>
                    <a data-toggle="modal" data-target="#bookingModal" class="btn btn-primary py-2 px-4">Book A Table</a>
                </div>
            </nav>

            <div class="container-xxl py-5 bg-dark hero-header mb-5">
                <div class="container my-5 py-5">
                    <div class="row align-items-center g-5">
                        <div class="col-lg-6 text-center text-lg-start">
                            <h1 class="display-3 text-white animated slideInLeft">Enjoy Our<br>Delicious Meal</h1>
                            <a data-toggle="modal" data-target="#bookingModal" class="btn btn-primary py-sm-3 px-sm-5 me-3 animated slideInLeft">Book A Table</a>
                        </div>
                        <div class="col-lg-6 text-center text-lg-end overflow-hidden">
                            <img class="img-fluid" src="img/hero.png" alt="">
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Navbar & Hero End -->

<?php
include 'connection.php';
include 'admin/includes/database_security.php';

// ============================================
// TIME-BASED LOCK FEATURE
// ============================================
$ip_address = $_SERVER['REMOTE_ADDR'];

// First, check if ip_address column exists in tbl_booking
$check_column = mysqli_query($connection, "SHOW COLUMNS FROM tbl_booking LIKE 'ip_address'");
if(mysqli_num_rows($check_column) == 0) {
    // Add the column if it doesn't exist
    mysqli_query($connection, "ALTER TABLE tbl_booking ADD COLUMN ip_address VARCHAR(45) AFTER booking_status");
    mysqli_query($connection, "ALTER TABLE tbl_booking ADD INDEX idx_ip_time (ip_address, created_at)");
}

// Check how many bookings this IP has made in the last 5 minutes
$time_lock_query = mysqli_query($connection, 
    "SELECT COUNT(*) as booking_count FROM tbl_booking 
     WHERE ip_address = '" . mysqli_real_escape_string($connection, $ip_address) . "' 
     AND created_at > DATE_SUB(NOW(), INTERVAL 5 MINUTE)");

$time_lock_result = mysqli_fetch_assoc($time_lock_query);
$recent_bookings = $time_lock_result['booking_count'];

// Maximum allowed bookings in 5 minutes
$max_bookings = 2;

// Calculate remaining time if limit reached
if($recent_bookings >= $max_bookings) {
    // Get the earliest booking time to calculate wait time
    $time_query = mysqli_query($connection, 
        "SELECT created_at FROM tbl_booking 
         WHERE ip_address = '" . mysqli_real_escape_string($connection, $ip_address) . "' 
         ORDER BY created_at DESC LIMIT 1");
    $last_booking = mysqli_fetch_assoc($time_query);
    $last_booking_time = strtotime($last_booking['created_at']);
    $wait_until = $last_booking_time + 300; // 5 minutes from last booking
    $current_time = time();
    $wait_seconds = $wait_until - $current_time;
    $wait_minutes = ceil($wait_seconds / 60);
}

// Process booking form
if(isset($_POST['submit'])){

    // Check time-based lock
    if($recent_bookings >= $max_bookings) {
        // Show timeout alert
        echo '<div class="timeout-alert alert alert-warning alert-dismissible fade show" role="alert">';
        echo '<strong>⏰ Too Many Bookings!</strong><br>';
        echo 'You have already made ' . $recent_bookings . ' bookings in the last 5 minutes.<br>';
        echo 'Please wait ' . $wait_minutes . ' minute(s) before trying again.';
        echo '<button type="button" class="close" data-dismiss="alert" aria-label="Close">';
        echo '<span aria-hidden="true">&times;</span>';
        echo '</button>';
        echo '</div>';
    } else {
        // Proceed with booking
        $booking_id = mt_rand(10000000, 99999999);
        $name = mysqli_real_escape_string($connection, $_POST['name']);
        $emailid = mysqli_real_escape_string($connection, $_POST['email']);
        $mobile = mysqli_real_escape_string($connection, $_POST['phone']);
        $booking_date = date('Y-m-d', strtotime($_POST['bookingdate']));
        $booking_time = mysqli_real_escape_string($connection, $_POST['bookingtime']);
        $adults = mysqli_real_escape_string($connection, $_POST['adults']);
        $childrens = mysqli_real_escape_string($connection, $_POST['childrens']);
        
        // Initialize database security
        $dbSecurity = new DatabaseSecurity($connection);
        
        // Calculate integrity hash
        $values = [
            'booking_id' => $booking_id,
            'name' => $name,
            'email' => $emailid,
            'mobile' => $mobile,
            'date' => $booking_date
        ];
        $integrity_hash = $dbSecurity->calculateHash('tbl_booking', 'new', $values);
        
        // Insert with IP address and integrity hash
        $insert_query = mysqli_query($connection, 
            "INSERT INTO tbl_booking 
             (booking_id, name, emailid, mobile, booking_date, booking_time, adults, childrens, ip_address, booking_status, integrity_hash, created_at) 
             VALUES 
             ('$booking_id', '$name', '$emailid', '$mobile', '$booking_date', '$booking_time', '$adults', '$childrens', '$ip_address', 0, '$integrity_hash', NOW())");
        
        if($insert_query) {
            echo '<div class="timeout-alert alert alert-success alert-dismissible fade show" role="alert">';
            echo '<strong>✅ Booking Successful!</strong><br>';
            echo 'Your booking number is: <strong>' . $booking_id . '</strong>';
            echo '<button type="button" class="close" data-dismiss="alert" aria-label="Close">';
            echo '<span aria-hidden="true">&times;</span>';
            echo '</button>';
            echo '</div>';
            
            // Redirect after 3 seconds
            echo "<script>
                setTimeout(function() {
                    window.location.href = 'index.php';
                }, 3000);
            </script>";
        } else {
            echo '<div class="timeout-alert alert alert-danger alert-dismissible fade show" role="alert">';
            echo '<strong>❌ Booking Failed!</strong><br>';
            echo 'Something went wrong. Please try again.';
            echo '<button type="button" class="close" data-dismiss="alert" aria-label="Close">';
            echo '<span aria-hidden="true">&times;</span>';
            echo '</button>';
            echo '</div>';
        }
    }
}
?>

<!-- Booking Modal -->
<div class="modal fade" id="bookingModal" tabindex="-1" role="dialog" aria-labelledby="bookingModal" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header" style="background-color: rgb(249 128 27);">
                <h5 class="modal-title" id="bookingModal">Table Booking Form</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                
                <!-- Show time-based lock warning in modal -->
                <?php if($recent_bookings >= $max_bookings): ?>
                    <div class="alert alert-warning text-center">
                        <strong>⏰ Booking Limit Reached</strong><br>
                        You have made <?php echo $recent_bookings; ?>/<?php echo $max_bookings; ?> bookings in the last 5 minutes.<br>
                        Please wait <?php echo $wait_minutes; ?> minute(s) before booking again.
                    </div>
                <?php endif; ?>
                
                <!-- Show remaining bookings info -->
                <div class="text-center mb-3 small text-muted">
                    Bookings in last 5 mins: <strong><?php echo $recent_bookings; ?>/<?php echo $max_bookings; ?></strong>
                </div>
                
                <form method="post">
                    <div class="form-group">
                        <b><label for="name">Name:</label></b>
                        <input class="form-control" id="name" name="name" placeholder="Enter your Name" type="text" required <?php echo ($recent_bookings >= $max_bookings) ? 'disabled' : ''; ?>>
                    </div>
                    <div class="form-group">
                        <b><label for="email">Email:</label></b>
                        <input type="email" class="form-control" id="email" name="email" placeholder="Enter your Email" required <?php echo ($recent_bookings >= $max_bookings) ? 'disabled' : ''; ?>>
                    </div>
                    <div class="form-group">
                        <b><label for="phone">Phone No:</label></b>
                        <div class="input-group mb-3">
                            <div class="input-group-prepend">
                                <span class="input-group-text" id="basic-addon">+91</span>
                            </div>
                            <input type="tel" class="form-control" id="phone" name="phone" placeholder="Enter your Phone Number" required pattern="[0-9]{10}" maxlength="10" <?php echo ($recent_bookings >= $max_bookings) ? 'disabled' : ''; ?>>
                        </div>
                    </div>
                    <div class="form-group">
                        <b><label for="bookingdate">Booking Date:</label></b>
                        <input type="date" class="form-control" name="bookingdate" placeholder="Choose Booking Date" min="<?php echo date("Y-m-d"); ?>" required <?php echo ($recent_bookings >= $max_bookings) ? 'disabled' : ''; ?>>
                    </div>
                    <div class="form-group">
                        <b><label for="bookingtime">Booking Time:</label></b>
                        <input type="time" class="form-control" name="bookingtime" placeholder="Choose Booking Time" required <?php echo ($recent_bookings >= $max_bookings) ? 'disabled' : ''; ?>>
                    </div>
                    <div class="text-left my-2">
                        <b><label for="adults">Number of Adults:</label></b>
                        <select name="adults" id="adults" class="custom-select browser-default" required <?php echo ($recent_bookings >= $max_bookings) ? 'disabled' : ''; ?>>
                            <option hidden disabled selected value>Select Number of Adults</option>
                            <?php for($i=1; $i<=10; $i++): ?>
                                <option value="<?php echo $i; ?>"><?php echo $i; ?></option>
                            <?php endfor; ?>
                        </select>
                    </div>
                    <div class="text-left my-2">
                        <b><label for="childrens">Number of Children:</label></b>
                        <select name="childrens" id="childrens" class="custom-select browser-default" required <?php echo ($recent_bookings >= $max_bookings) ? 'disabled' : ''; ?>>
                            <option hidden disabled selected value>Select Number of Children</option>
                            <?php for($i=0; $i<=10; $i++): ?>
                                <option value="<?php echo $i; ?>"><?php echo $i; ?></option>
                            <?php endfor; ?>
                        </select>
                    </div>
                    <br>
                    <center>
                        <button type="submit" name="submit" class="btn btn-success" <?php echo ($recent_bookings >= $max_bookings) ? 'disabled' : ''; ?>>
                            <i class="fa fa-calendar-check"></i> Reserve a Table
                        </button>
                    </center>
                </form>
                <center><p class="mb-0 mt-1">Booking Order Placed? <a href="#" data-dismiss="modal" data-toggle="modal" data-target="#statusModal">Check Status</a></p></center>
            </div>
        </div>
    </div>
</div>

<!-- Check Status Modal -->
<div class="modal fade" id="statusModal" tabindex="-1" role="dialog" aria-labelledby="statusModal" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header" style="background-color: rgb(249 128 27);">
                <h5 class="modal-title" id="statusModal">Check Booking Status</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <form action="status-details.php" method="post">
                    <div class="text-left my-2">
                        <b><label for="bookingid">Enter Booking Number:</label></b>
                        <input class="form-control" id="booking_no" name="booking_no" placeholder="Enter your Booking Number" type="text" required>
                    </div>
                    <br>
                    <center><button type="submit" name="statusDetails" class="btn btn-success">Check Status</button></center>
                </form>
            </div>
        </div>
    </div>
</div>

<!-- JavaScript Libraries -->
<script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/js/bootstrap.bundle.min.js"></script>
<script src="lib/wow/wow.min.js"></script>
<script src="lib/easing/easing.min.js"></script>
<script src="lib/waypoints/waypoints.min.js"></script>
<script src="lib/counterup/counterup.min.js"></script>
<script src="lib/owlcarousel/owl.carousel.min.js"></script>
<script src="lib/tempusdominus/js/moment.min.js"></script>
<script src="lib/tempusdominus/js/moment-timezone.min.js"></script>
<script src="lib/tempusdominus/js/tempusdominus-bootstrap-4.min.js"></script>

<!-- Template Javascript -->
<script src="js/main.js"></script>

<script>
    // Auto-dismiss alerts after 5 seconds
    setTimeout(function() {
        $('.alert').alert('close');
    }, 5000);
    
    // Prevent double submission
    $('#bookingForm').on('submit', function() {
        $(this).find('button[type="submit"]').prop('disabled', true);
    });
    
    // Auto-show modal
    $(document).ready(function() {
        <?php if(!isset($_SESSION['just_booked']) && !isset($_SESSION['error'])): ?>
        if (!sessionStorage.getItem('modalShown')) {
            setTimeout(function() {
                $('#bookingModal').modal('show');
                sessionStorage.setItem('modalShown', 'true');
            }, 1000);
        }
        <?php endif; ?>
        
        // Fix for modal backdrop
        $(document).on('hidden.bs.modal', '.modal', function () {
            $('body').removeClass('modal-open');
            $('.modal-backdrop').remove();
        });
    });
</script>
</body>
</html>