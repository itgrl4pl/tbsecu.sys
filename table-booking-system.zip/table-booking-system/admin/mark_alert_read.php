<?php
session_start();
include 'partials/connection.php';

if(isset($_GET['id'])) {
    $id = $_GET['id'];
    mysqli_query($conn, "UPDATE security_alerts SET is_read = 1 WHERE id = '$id'");
}

header("location: index.php");
exit();
?>