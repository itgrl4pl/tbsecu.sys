<?php
if($_SERVER["REQUEST_METHOD"] == "POST"){
    include 'connection.php';
    include '../includes/behavior_analysis.php';
    include '../includes/session_security.php';  // ADD THIS LINE
    
    $username = $_POST["username"];
    $password = $_POST["password"]; 
    
    $sql = "Select * from users where username='$username'"; 
    $result = mysqli_query($conn, $sql);
    $num = mysqli_num_rows($result);
    
    if ($num == 1){
        $row=mysqli_fetch_assoc($result);
        $userType = $row['userType'];
        
        if($userType == 1) {
            $userId = $row['id'];
            if (password_verify($password, $row['password'])){ 
                session_start();
                
                // Initialize session with fingerprint
                $sessionSec = new SessionSecurity($conn);
                $fingerprint = $sessionSec->initSession($userId);
                
                $_SESSION['adminloggedin'] = true;
                $_SESSION['adminusername'] = $username;
                $_SESSION['adminuserId'] = $userId;
                $_SESSION['fingerprint'] = $fingerprint;  // Store fingerprint
                
                // Track successful login
                $analyzer = new AdminBehaviorAnalysis($conn, $userId);
                $alerts = $analyzer->trackLogin();
                
                header("location: /table-booking-system/admin/index.php?loginsuccess=true");
                exit();
            } 
            else{
                // Track failed login
                $analyzer = new AdminBehaviorAnalysis($conn, 0);
                $analyzer->trackFailedLogin($username);
                
                header("location: /table-booking-system/admin/login.php?loginsuccess=false");
            }
        }
        else {
            header("location: /table-booking-system/admin/login.php?loginsuccess=false");
        }
    } 
    else{
        // Track failed login
        $analyzer = new AdminBehaviorAnalysis($conn, 0);
        $analyzer->trackFailedLogin($username);
        
        header("location: /table-booking-system/admin/login.php?loginsuccess=false");
    }
}    
?>