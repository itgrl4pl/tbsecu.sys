<?php
include 'header.php';

if(!$adminloggedin) {
    header("location: login.php");
    exit();
}

$success_msg = '';
$error_msg = '';

// Get current admin info
$user_id = $_SESSION['adminuserId'];
$query = mysqli_query($conn, "SELECT * FROM users WHERE id = '$user_id'");
$admin = mysqli_fetch_assoc($query);

// Handle profile update
if(isset($_POST['update_profile'])) {
    $username = mysqli_real_escape_string($conn, $_POST['username']);
    $email = mysqli_real_escape_string($conn, $_POST['email']);
    $phone = mysqli_real_escape_string($conn, $_POST['phone']);
    
    $update = mysqli_query($conn, "UPDATE users SET username='$username', email='$email', phone='$phone' WHERE id='$user_id'");
    
    if($update) {
        $success_msg = "✅ Profile updated successfully!";
        // Refresh admin data
        $query = mysqli_query($conn, "SELECT * FROM users WHERE id = '$user_id'");
        $admin = mysqli_fetch_assoc($query);
    } else {
        $error_msg = "❌ Error updating profile!";
    }
}

// Handle password change
if(isset($_POST['change_password'])) {
    $current = $_POST['current_password'];
    $new = $_POST['new_password'];
    $confirm = $_POST['confirm_password'];
    
    if(!password_verify($current, $admin['password'])) {
        $error_msg = "❌ Current password is incorrect!";
    }
    elseif($new != $confirm) {
        $error_msg = "❌ New passwords do not match!";
    }
    elseif(strlen($new) < 6) {
        $error_msg = "❌ Password must be at least 6 characters!";
    }
    else {
        $hashed = password_hash($new, PASSWORD_DEFAULT);
        $update = mysqli_query($conn, "UPDATE users SET password='$hashed' WHERE id='$user_id'");
        
        if($update) {
            $success_msg = "✅ Password changed successfully!";
        } else {
            $error_msg = "❌ Error updating password!";
        }
    }
}
?>

<div class="page-wrapper">
    <div class="content">
        <div class="row">
            <div class="col-sm-12">
                <h4 class="page-title">
                    <i class="fa fa-user-circle"></i> Profile Settings
                    <a href="index.php" class="btn btn-primary float-right">Back to Dashboard</a>
                </h4>
            </div>
        </div>
        
        <?php if($success_msg): ?>
            <div class="alert alert-success alert-dismissible fade show"><?php echo $success_msg; ?><button type="button" class="close" data-dismiss="alert">&times;</button></div>
        <?php endif; ?>
        
        <?php if($error_msg): ?>
            <div class="alert alert-danger alert-dismissible fade show"><?php echo $error_msg; ?><button type="button" class="close" data-dismiss="alert">&times;</button></div>
        <?php endif; ?>
        
        <div class="row">
            <!-- Profile Information -->
            <div class="col-md-6">
                <div class="card">
                    <div class="card-header bg-primary text-white">
                        <h5 class="mb-0"><i class="fa fa-user"></i> Profile Information</h5>
                    </div>
                    <div class="card-body">
                        <form method="POST">
                            <div class="form-group">
                                <label>Username</label>
                                <input type="text" name="username" class="form-control" value="<?php echo $admin['username']; ?>" required>
                            </div>
                            <div class="form-group">
                                <label>Email</label>
                                <input type="email" name="email" class="form-control" value="<?php echo $admin['email']; ?>" required>
                            </div>
                            <div class="form-group">
                                <label>Phone</label>
                                <input type="text" name="phone" class="form-control" value="<?php echo $admin['phone']; ?>" required>
                            </div>
                            <button type="submit" name="update_profile" class="btn btn-success">
                                <i class="fa fa-save"></i> Update Profile
                            </button>
                        </form>
                    </div>
                </div>
            </div>
            
            <!-- Change Password -->
            <div class="col-md-6">
                <div class="card">
                    <div class="card-header bg-warning text-white">
                        <h5 class="mb-0"><i class="fa fa-key"></i> Change Password</h5>
                    </div>
                    <div class="card-body">
                        <form method="POST">
                            <div class="form-group">
                                <label>Current Password</label>
                                <input type="password" name="current_password" class="form-control" required>
                            </div>
                            <div class="form-group">
                                <label>New Password</label>
                                <input type="password" name="new_password" class="form-control" required minlength="6">
                                <small class="text-muted">Minimum 6 characters</small>
                            </div>
                            <div class="form-group">
                                <label>Confirm New Password</label>
                                <input type="password" name="confirm_password" class="form-control" required>
                            </div>
                            <button type="submit" name="change_password" class="btn btn-warning">
                                <i class="fa fa-key"></i> Change Password
                            </button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- Admin Info Card -->
        <div class="row mt-4">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header bg-info text-white">
                        <h5 class="mb-0"><i class="fa fa-info-circle"></i> Account Information</h5>
                    </div>
                    <div class="card-body">
                        <table class="table table-bordered">
                            <tr>
                                <th width="200">Admin ID</th>
                                <td><?php echo $admin['id']; ?></td>
                            </tr>
                            <tr>
                                <th>Username</th>
                                <td><?php echo $admin['username']; ?></td>
                            </tr>
                            <tr>
                                <th>Email</th>
                                <td><?php echo $admin['email']; ?></td>
                            </tr>
                            <tr>
                                <th>Phone</th>
                                <td><?php echo $admin['phone']; ?></td>
                            </tr>
                            <tr>
                                <th>Account Type</th>
                                <td><span class="badge badge-danger">Administrator</span></td>
                            </tr>
                            <tr>
                                <th>Last Login</th>
                                <td>
                                    <?php
                                    $last_login = mysqli_query($conn, "SELECT login_time FROM admin_behavior WHERE admin_id='$user_id' ORDER BY login_time DESC LIMIT 1");
                                    if(mysqli_num_rows($last_login) > 0) {
                                        $last = mysqli_fetch_assoc($last_login);
                                        echo date('d-m-Y H:i:s', strtotime($last['login_time']));
                                    } else {
                                        echo "First login";
                                    }
                                    ?>
                                </td>
                            </tr>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php include 'footer.php'; ?>