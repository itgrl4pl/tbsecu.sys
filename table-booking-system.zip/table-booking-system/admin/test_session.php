<?php
include 'header.php';
include 'includes/session_security.php';

if(!$adminloggedin) {
    header("location: login.php");
    exit();
}

$sessionSec = new SessionSecurity($conn);
$message = '';
$message_type = '';

if(isset($_GET['action'])) {
    switch($_GET['action']) {
        case 'check':
            if($sessionSec->verifySession()) {
                $message = "✅ Session is valid and secure";
                $message_type = 'success';
            } else {
                $message = "❌ Session verification failed!";
                $message_type = 'danger';
            }
            break;
            
        case 'terminate':
            $count = $sessionSec->terminateOtherSessions();
            $message = "✅ Terminated $count other session(s)";
            $message_type = 'success';
            break;
            
        case 'simulate_hijack':
            // Simulate different browser
            $_SERVER['HTTP_USER_AGENT'] = 'Fake Browser 1.0';
            if(!$sessionSec->verifySession()) {
                $message = "🔴 Hijack detected! Session would be terminated.";
                $message_type = 'danger';
            }
            break;
    }
}

$active_sessions = $sessionSec->getActiveSessions();
$stats = $sessionSec->getStats();
?>

<div class="page-wrapper">
    <div class="content">
        <div class="row">
            <div class="col-sm-12">
                <h4 class="page-title">
                    <i class="fa fa-fingerprint"></i> Session Security Test
                    <a href="index.php" class="btn btn-primary float-right">Dashboard</a>
                </h4>
            </div>
        </div>
        
        <?php if($message): ?>
            <div class="alert alert-<?php echo $message_type; ?>"><?php echo $message; ?></div>
        <?php endif; ?>
        
        <!-- Stats Cards -->
        <div class="row mb-4">
            <div class="col-md-6">
                <div class="card bg-info text-white">
                    <div class="card-body text-center">
                        <h3><?php echo $stats['active_sessions']; ?></h3>
                        <small>Active Sessions</small>
                    </div>
                </div>
            </div>
            <div class="col-md-6">
                <div class="card bg-warning text-white">
                    <div class="card-body text-center">
                        <h3><?php echo $stats['hijack_attempts_24h']; ?></h3>
                        <small>Hijack Attempts (24h)</small>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- Test Buttons -->
        <div class="row mb-4">
            <div class="col-md-4">
                <a href="?action=check" class="btn btn-info btn-block py-3">
                    <i class="fa fa-check-circle fa-2x"></i><br>
                    Verify Session
                </a>
            </div>
            <div class="col-md-4">
                <a href="?action=terminate" class="btn btn-warning btn-block py-3">
                    <i class="fa fa-ban fa-2x"></i><br>
                    Terminate Other Sessions
                </a>
            </div>
            <div class="col-md-4">
                <a href="?action=simulate_hijack" class="btn btn-danger btn-block py-3">
                    <i class="fa fa-exclamation-triangle fa-2x"></i><br>
                    Simulate Hijack
                </a>
            </div>
        </div>
        
        <!-- Active Sessions Table -->
        <div class="card">
            <div class="card-header bg-dark text-white">
                <h5 class="mb-0">Active Sessions</h5>
            </div>
            <div class="card-body">
                <table class="table table-bordered">
                    <thead>
                        <tr>
                            <th>Login Time</th>
                            <th>IP Address</th>
                            <th>Browser</th>
                            <th>Status</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach($active_sessions as $session): ?>
                        <tr class="<?php echo $session['is_current'] ? 'table-success' : ''; ?>">
                            <td><?php echo date('Y-m-d H:i:s', strtotime($session['login_time'])); ?></td>
                            <td><?php echo $session['ip_address']; ?></td>
                            <td><?php echo substr($session['user_agent'], 0, 50) . '...'; ?></td>
                            <td>
                                <?php if($session['is_current']): ?>
                                    <span class="badge badge-success">Current Session</span>
                                <?php else: ?>
                                    <span class="badge badge-secondary">Active</span>
                                <?php endif; ?>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
        
        <!-- How to Test -->
        <div class="card mt-4">
            <div class="card-header bg-info text-white">
                <h5 class="mb-0">📋 How to Test Session Fingerprinting</h5>
            </div>
            <div class="card-body">
                <ol>
                    <li><strong>Current Session:</strong> Click "Verify Session" - should show success</li>
                    <li><strong>Test Hijacking:</strong> Click "Simulate Hijack" - should show failure</li>
                    <li><strong>Real Test:</strong> 
                        <ul>
                            <li>Open Chrome and login to admin</li>
                            <li>Copy the session cookie to Firefox/Edge</li>
                            <li>Try to access admin page - should be blocked</li>
                        </ul>
                    </li>
                    <li><strong>Clean Up:</strong> Click "Terminate Other Sessions" to logout all other devices</li>
                </ol>
            </div>
        </div>
    </div>
</div>

<?php include 'footer.php'; ?>