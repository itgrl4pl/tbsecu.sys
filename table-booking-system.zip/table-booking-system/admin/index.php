<?php 
include 'header.php';    
if($adminloggedin) {
?>
<body> 
    <div class="page-wrapper">
        <div class="content">
            <!-- Page Title -->
            <div class="row">
                <div class="col-sm-12">
                    <h4 class="page-title">
                        <i class="fa fa-dashboard"></i> Admin Dashboard
                        <small class="text-muted">Welcome back, <?php echo $_SESSION['adminusername']; ?></small>
                    </h4>
                </div>
            </div>

            <!-- Booking Statistics Section -->
            <div class="row">
                <div class="col-12">
                    <h5 class="mb-3"><i class="fa fa-calendar"></i> Booking Overview</h5>
                </div>
                <div class="col-md-6 col-sm-6 col-lg-6 col-xl-4">
                    <div class="dash-widget">
                        <span class="dash-widget-bg1"><i class="fa fa-user" aria-hidden="true"></i></span>
                        <?php
                        $fetch_query = mysqli_query($conn, "select count(*) as total from tbl_booking"); 
                        $booking = mysqli_fetch_row($fetch_query);
                        ?>
                        <div class="dash-widget-info text-right">
                            <h3><?php echo $booking[0]; ?></h3>
                            <span class="widget-title1">All Bookings <i class="fa fa-check" aria-hidden="true"></i></span>
                        </div>
                    </div>
                </div>
                <div class="col-md-6 col-sm-6 col-lg-6 col-xl-4">
                    <div class="dash-widget">
                        <span class="dash-widget-bg2"><i class="fa fa-bar-chart"></i></span>
                        <?php
                        $fetch_query = mysqli_query($conn, "select count(*) as total from tbl_booking where date(created_at)=CURDATE()"); 
                        $today_booking = mysqli_fetch_row($fetch_query);
                        ?>
                        <div class="dash-widget-info text-right">
                            <h3><?php echo $today_booking[0]; ?></h3>
                            <span class="widget-title2">Today Bookings <i class="fa fa-check" aria-hidden="true"></i></span>
                        </div>
                    </div>
                </div>
                <div class="col-md-6 col-sm-6 col-lg-6 col-xl-4">
                    <div class="dash-widget">
                        <span class="dash-widget-bg3"><i class="fa fa-bar-chart" aria-hidden="true"></i></span>
                        <?php
                        $fetch_query = mysqli_query($conn, "select count(*) as total from tbl_booking where DATE(created_at)=CURDATE()-1"); 
                        $yesterday_booking = mysqli_fetch_row($fetch_query);
                        ?>
                        <div class="dash-widget-info text-right">
                            <h3><?php echo $yesterday_booking[0]; ?></h3>
                            <span class="widget-title3">Yesterday Bookings <i class="fa fa-check" aria-hidden="true"></i></span>
                        </div>
                    </div>
                </div>
                <div class="col-md-6 col-sm-6 col-lg-6 col-xl-4">
                    <div class="dash-widget">
                        <span class="dash-widget-bg3"><i class="fa fa-bar-chart" aria-hidden="true"></i></span>
                        <?php
                        $fetch_query = mysqli_query($conn, "select count(*) as total from tbl_booking where week(DATE(created_at))=week(now())"); 
                        $week_booking = mysqli_fetch_row($fetch_query);
                        ?>
                        <div class="dash-widget-info text-right">
                            <h3><?php echo $week_booking[0]; ?></h3>
                            <span class="widget-title3">This Week Bookings <i class="fa fa-check" aria-hidden="true"></i></span>
                        </div>
                    </div>
                </div>
                <div class="col-md-6 col-sm-6 col-lg-6 col-xl-4">
                    <div class="dash-widget">
                        <span class="dash-widget-bg4"><i class="fa fa-handshake-o" aria-hidden="true"></i></span>
                        <?php
                        $fetch_query = mysqli_query($conn, "select count(*) as total from tbl_booking where booking_status=1"); 
                        $accept_booking = mysqli_fetch_row($fetch_query);
                        ?>
                        <div class="dash-widget-info text-right">
                            <h3><?php echo $accept_booking[0]; ?></h3>
                            <span class="widget-title4">Accepted Bookings <i class="fa fa-check" aria-hidden="true"></i></span>
                        </div>
                    </div>
                </div>
                <div class="col-md-6 col-sm-6 col-lg-6 col-xl-4">
                    <div class="dash-widget">
                        <span class="dash-widget-bg5"><i class="fa fa-close" aria-hidden="true"></i></span>
                        <?php
                        $fetch_query = mysqli_query($conn, "select count(*) as total from tbl_booking where booking_status=2"); 
                        $cancel_booking = mysqli_fetch_row($fetch_query);
                        ?>
                        <div class="dash-widget-info text-right">
                            <h3><?php echo $cancel_booking[0]; ?></h3>
                            <span class="widget-title5">Cancelled Bookings <i class="fa fa-check" aria-hidden="true"></i></span>
                        </div>
                    </div>
                </div>
            </div>

            <!-- ========== SECURITY DASHBOARD SECTION ========== -->
            <?php
            // Include behavior analysis class
            include 'includes/behavior_analysis.php';
            include 'includes/session_security.php';
            include 'includes/database_security.php';
            include 'includes/audit_trail.php';
            include 'includes/action_approval.php';
            
            // Get stats for current admin
            $analyzer = new AdminBehaviorAnalysis($conn, $userId);
            $stats = $analyzer->getTodayStats();
            $recent_alerts = $analyzer->getRecentAlerts(5);
            $current_ip = $_SERVER['REMOTE_ADDR'];
            
            // Get other security stats
            $sessionSec = new SessionSecurity($conn);
            $session_stats = $sessionSec->getStats();
            
            $dbSecurity = new DatabaseSecurity($conn);
            $tamper_stats = $dbSecurity->getStats();
            
            $audit = new AuditTrail($conn);
            $audit_stats = $audit->getStats();
            
            $approval = new ActionApproval($conn);
            $approval_stats = $approval->getStats();
            ?>

            <!-- Security Dashboard Title -->
            <div class="row mt-4">
                <div class="col-12">
                    <h4 class="page-title border-bottom pb-2">
                        <i class="fa fa-shield text-primary"></i> Security Dashboard
                        <small class="text-muted">Real-time security monitoring</small>
                    </h4>
                </div>
            </div>

            <!-- Security Overview Cards -->
            <div class="row">
                <div class="col-md-3">
                    <div class="small-box bg-info">
                        <div class="inner">
                            <h3><?php echo $stats['today_logins']; ?></h3>
                            <p>Today's Logins</p>
                        </div>
                        <div class="icon">
                            <i class="fa fa-sign-in"></i>
                        </div>
                        <a href="test_session.php" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="small-box bg-primary">
                        <div class="inner">
                            <h3><?php echo $session_stats['active_sessions']; ?></h3>
                            <p>Active Sessions</p>
                        </div>
                        <div class="icon">
                            <i class="fa fa-laptop"></i>
                        </div>
                        <a href="test_session.php" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="small-box bg-warning">
                        <div class="inner">
                            <h3><?php echo $stats['unread_alerts']; ?></h3>
                            <p>Security Alerts</p>
                        </div>
                        <div class="icon">
                            <i class="fa fa-exclamation-triangle"></i>
                        </div>
                        <a href="#" onclick="viewSecurityAlerts()" class="small-box-footer">View Alerts <i class="fa fa-arrow-circle-right"></i></a>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="small-box bg-success">
                        <div class="inner">
                            <h3><?php echo $approval_stats['pending_approvals']; ?></h3>
                            <p>Pending Approvals</p>
                        </div>
                        <div class="icon">
                            <i class="fa fa-clock-o"></i>
                        </div>
                        <a href="test_approval.php" class="small-box-footer">Manage <i class="fa fa-arrow-circle-right"></i></a>
                    </div>
                </div>
            </div>

            <!-- Second Row of Security Cards -->
            <div class="row">
                <div class="col-md-4">
                    <div class="info-box">
                        <span class="info-box-icon bg-danger"><i class="fa fa-database"></i></span>
                        <div class="info-box-content">
                            <span class="info-box-text">Tampering Attempts</span>
                            <span class="info-box-number"><?php echo $tamper_stats['total_tampering']; ?></span>
                            <div class="progress">
                                <div class="progress-bar bg-danger" style="width: <?php echo min(100, $tamper_stats['last_24h'] * 10); ?>%"></div>
                            </div>
                            <span class="progress-description"><?php echo $tamper_stats['last_24h']; ?> in last 24h</span>
                        </div>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="info-box">
                        <span class="info-box-icon bg-warning"><i class="fa fa-history"></i></span>
                        <div class="info-box-content">
                            <span class="info-box-text">Today's Changes</span>
                            <span class="info-box-number"><?php echo $audit_stats['today_changes']; ?></span>
                            <div class="progress">
                                <div class="progress-bar bg-warning" style="width: <?php echo min(100, $audit_stats['today_changes'] * 5); ?>%"></div>
                            </div>
                            <span class="progress-description">Week: <?php echo $audit_stats['week_changes']; ?></span>
                        </div>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="info-box">
                        <span class="info-box-icon bg-info"><i class="fa fa-globe"></i></span>
                        <div class="info-box-content">
                            <span class="info-box-text">Unique IPs</span>
                            <span class="info-box-number"><?php echo $stats['unique_ips']; ?></span>
                            <span class="info-box-text small">Current: <code><?php echo $current_ip; ?></code></span>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Recent Alerts Table -->
            <div class="row mt-3">
                <div class="col-12">
                    <div class="card card-outline card-danger">
                        <div class="card-header">
                            <h3 class="card-title"><i class="fa fa-exclamation-triangle"></i> Recent Security Alerts</h3>
                            <div class="card-tools">
                                <button type="button" class="btn btn-tool" onclick="viewSecurityAlerts()">
                                    <i class="fa fa-external-link"></i> View All
                                </button>
                            </div>
                        </div>
                        <div class="card-body p-0">
                            <div class="table-responsive">
                                <table class="table table-striped">
                                    <thead>
                                        <tr>
                                            <th>Time</th>
                                            <th>Type</th>
                                            <th>Message</th>
                                            <th>Severity</th>
                                            <th>Status</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php if(empty($recent_alerts)): ?>
                                        <tr>
                                            <td colspan="5" class="text-center text-success py-3">
                                                <i class="fa fa-check-circle fa-2x"></i><br>
                                                No security alerts - all clear!
                                            </td>
                                        </tr>
                                        <?php else: ?>
                                            <?php foreach($recent_alerts as $alert): ?>
                                            <tr>
                                                <td><?php echo date('H:i:s', strtotime($alert['alert_time'])); ?></td>
                                                <td>
                                                    <?php 
                                                    $badge = 'secondary';
                                                    $label = ucfirst(str_replace('_', ' ', $alert['alert_type']));
                                                    switch($alert['alert_type']) {
                                                        case 'new_ip': $badge = 'info'; break;
                                                        case 'unusual_hour': $badge = 'warning'; break;
                                                        case 'brute_force': $badge = 'danger'; break;
                                                        case 'rapid_login': $badge = 'danger'; break;
                                                        case 'tampering': $badge = 'danger'; $label = 'Tampering'; break;
                                                        case 'session_hijack': $badge = 'danger'; $label = 'Hijack'; break;
                                                    }
                                                    ?>
                                                    <span class="badge badge-<?php echo $badge; ?>"><?php echo $label; ?></span>
                                                </td>
                                                <td><?php echo $alert['message']; ?></td>
                                                <td>
                                                    <span class="badge badge-<?php echo $alert['severity'] == 'high' ? 'danger' : ($alert['severity'] == 'medium' ? 'warning' : 'info'); ?>">
                                                        <?php echo ucfirst($alert['severity']); ?>
                                                    </span>
                                                </td>
                                                <td>
                                                    <?php if($alert['is_read'] == 0): ?>
                                                        <span class="badge badge-warning">New</span>
                                                    <?php else: ?>
                                                        <span class="badge badge-secondary">Read</span>
                                                    <?php endif; ?>
                                                </td>
                                            </tr>
                                            <?php endforeach; ?>
                                        <?php endif; ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Security Quick Actions -->
            <div class="row mt-3">
                <div class="col-12">
                    <div class="card card-outline card-secondary">
                        <div class="card-header">
                            <h3 class="card-title"><i class="fa fa-bolt"></i> Security Tools</h3>
                        </div>
                        <div class="card-body">
                            <div class="row">
                                <div class="col-md-2 col-sm-4 col-6 mb-2">
                                    <a href="test_session.php" class="btn btn-outline-primary btn-block py-2">
                                        <i class="fa fa-fingerprint fa-2x d-block mb-1"></i>
                                        <small>Session Test</small>
                                    </a>
                                </div>
                                <div class="col-md-2 col-sm-4 col-6 mb-2">
                                    <a href="test_tampering.php" class="btn btn-outline-warning btn-block py-2">
                                        <i class="fa fa-database fa-2x d-block mb-1"></i>
                                        <small>Tamper Test</small>
                                    </a>
                                </div>
                                <div class="col-md-2 col-sm-4 col-6 mb-2">
                                    <a href="test_audit.php" class="btn btn-outline-info btn-block py-2">
                                        <i class="fa fa-history fa-2x d-block mb-1"></i>
                                        <small>Audit Test</small>
                                    </a>
                                </div>
                                <div class="col-md-2 col-sm-4 col-6 mb-2">
                                    <a href="test_approval.php" class="btn btn-outline-success btn-block py-2">
                                        <i class="fa fa-lock fa-2x d-block mb-1"></i>
                                        <small>Approval Test</small>
                                    </a>
                                </div>
                                <div class="col-md-2 col-sm-4 col-6 mb-2">
                                    <a href="tampering_logs.php" class="btn btn-outline-danger btn-block py-2">
                                        <i class="fa fa-exclamation-triangle fa-2x d-block mb-1"></i>
                                        <small>Tamper Logs</small>
                                    </a>
                                </div>
                                <div class="col-md-2 col-sm-4 col-6 mb-2">
                                    <a href="profile_settings.php" class="btn btn-outline-secondary btn-block py-2">
                                        <i class="fa fa-key fa-2x d-block mb-1"></i>
                                        <small>Change Password</small>
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Database Integrity Monitor -->
            <div class="row mt-3">
                <div class="col-12">
                    <div class="card card-outline card-danger">
                        <div class="card-header">
                            <h3 class="card-title"><i class="fa fa-database"></i> Database Integrity Monitor</h3>
                            <div class="card-tools">
                                <button onclick="scanDatabase()" class="btn btn-sm btn-primary">
                                    <i class="fa fa-search"></i> Scan Now
                                </button>
                                <a href="tampering_logs.php" class="btn btn-sm btn-info">
                                    <i class="fa fa-history"></i> View Logs
                                </a>
                            </div>
                        </div>
                        <div class="card-body">
                            <?php
                            $tampered = $dbSecurity->fullScan();
                            ?>
                            <div class="row">
                                <div class="col-md-3 col-sm-6">
                                    <div class="small-box bg-info">
                                        <div class="inner">
                                            <h3><?php echo $tamper_stats['total_tampering']; ?></h3>
                                            <p>Total Attempts</p>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-3 col-sm-6">
                                    <div class="small-box bg-warning">
                                        <div class="inner">
                                            <h3><?php echo $tamper_stats['last_24h']; ?></h3>
                                            <p>Last 24h</p>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="info-box <?php echo empty($tampered) ? 'bg-success' : 'bg-danger'; ?> text-white">
                                        <span class="info-box-icon"><i class="fa fa-shield"></i></span>
                                        <div class="info-box-content">
                                            <span class="info-box-text">Current Status</span>
                                            <span class="info-box-number">
                                                <?php if(empty($tampered)): ?>
                                                    ✅ All Records Intact
                                                <?php else: ?>
                                                    ⚠️ Tampering Detected (<?php echo count($tampered); ?> records)
                                                <?php endif; ?>
                                            </span>
                                            <?php if(!empty($tampered)): ?>
                                                <div class="mt-2">
                                                    <small><?php echo implode(', ', array_slice($tampered, 0, 3)); ?></small>
                                                </div>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Your existing booking details and table list -->
            <div class="row mt-4">
                <div class="col-12 col-md-6 col-lg-8 col-xl-8">
                    <div class="card card-outline card-primary">
                        <div class="card-header">
                            <h4 class="card-title d-inline-block">Recent Bookings</h4>
                            <div class="card-tools">
                                <a href="booking.php" class="btn btn-primary btn-sm">View all</a>
                            </div>
                        </div>
                        <div class="card-body p-0">
                            <div class="table-responsive">
                                <table class="table table-striped">
                                    <thead>
                                        <tr>
                                            <th>Id</th>
                                            <th>Booking No.</th>
                                            <th>Name</th>
                                            <th>Phone</th>
                                            <th>Status</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php
                                        $sql = "SELECT * FROM `tbl_booking` order by created_at desc limit 5"; 
                                        $result = mysqli_query($conn, $sql);
                                        
                                        while($row=mysqli_fetch_assoc($result)) {
                                            $Id = $row['id'];
                                            $booking_id = $row['booking_id'];
                                            $name = $row['name'];
                                            $mobile = $row['mobile'];
                                            $booking_status = $row['booking_status'];
                                            if($booking_status == 0) {
                                                $bookStatus = "<span class='badge badge-primary'>New Booking</span>";
                                            }
                                            else if($booking_status == 1){
                                                $bookStatus = "<span class='badge badge-success'>Confirmed</span>";
                                            }
                                            else
                                            {
                                                $bookStatus = "<span class='badge badge-danger'>Rejected</span>";
                                            }
                                        ?>
                                        <tr>
                                            <td><?php echo $Id; ?></td>
                                            <td><?php echo $booking_id; ?></td>
                                            <td><?php echo $name; ?></td> 
                                            <td><?php echo $mobile; ?></td> 
                                            <td><?php echo $bookStatus; ?></td>
                                        </tr>
                                        <?php } ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-12 col-md-6 col-lg-4 col-xl-4">
                    <div class="card card-outline card-success">
                        <div class="card-header">
                            <h4 class="card-title">Available Tables</h4>
                        </div>
                        <div class="card-body p-0">
                            <ul class="list-group list-group-flush">
                                <?php 
                                $sql = "SELECT * FROM `tbl_table` LIMIT 8"; 
                                $result = mysqli_query($conn, $sql);
                                while($row = mysqli_fetch_assoc($result)){
                                    $table_no = $row['table_no'];
                                ?>
                                <li class="list-group-item d-flex justify-content-between align-items-center">
                                    <?php echo $table_no; ?>
                                    <span class="badge badge-success badge-pill">Available</span>
                                </li>
                                <?php } ?>
                            </ul>
                        </div>
                        <div class="card-footer text-center">
                            <a href="manage-table.php" class="btn btn-sm btn-success">Manage Tables</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

<?php
    }
    else{
        header("location: /table-booking-system/admin/login.php");
    }
?>
<!-- JavaScript for modals -->
<script>
function viewSecurityLogs() {
    $.ajax({
        url: 'ajax_security_logs.php',
        method: 'GET',
        success: function(response) {
            var modal = `
                <div class="modal fade" id="logsModal" tabindex="-1">
                    <div class="modal-dialog modal-lg">
                        <div class="modal-content">
                            <div class="modal-header bg-primary text-white">
                                <h5 class="modal-title">Security Logs</h5>
                                <button type="button" class="close" data-dismiss="modal">&times;</button>
                            </div>
                            <div class="modal-body">
                                ${response}
                            </div>
                        </div>
                    </div>
                </div>
            `;
            $('#logsModal').remove();
            $('body').append(modal);
            $('#logsModal').modal('show');
        },
        error: function() {
            alert('Could not load security logs');
        }
    });
}

function viewSecurityAlerts() {
    $.ajax({
        url: 'ajax_security_alerts.php',
        method: 'GET',
        success: function(response) {
            var modal = `
                <div class="modal fade" id="alertsModal" tabindex="-1">
                    <div class="modal-dialog modal-lg">
                        <div class="modal-content">
                            <div class="modal-header bg-warning text-white">
                                <h5 class="modal-title">Security Alerts</h5>
                                <button type="button" class="close" data-dismiss="modal">&times;</button>
                            </div>
                            <div class="modal-body">
                                ${response}
                            </div>
                        </div>
                    </div>
                </div>
            `;
            $('#alertsModal').remove();
            $('body').append(modal);
            $('#alertsModal').modal('show');
        },
        error: function() {
            alert('Could not load security alerts');
        }
    });
}

function scanDatabase() {
    $.ajax({
        url: 'scan_database.php',
        method: 'POST',
        success: function() {
            location.reload();
        }
    });
}
</script>

<!-- Add CSS for new UI elements -->
<style>
.small-box {
    border-radius: 0.25rem;
    box-shadow: 0 0 1px rgba(0,0,0,.125), 0 1px 3px rgba(0,0,0,.2);
    display: block;
    margin-bottom: 20px;
    position: relative;
    color: #fff;
}
.small-box > .inner {
    padding: 10px;
}
.small-box h3 {
    font-size: 2.2rem;
    font-weight: 700;
    margin: 0 0 10px;
    padding: 0;
    white-space: nowrap;
}
.small-box p {
    font-size: 1rem;
}
.small-box .icon {
    color: rgba(0,0,0,.15);
    position: absolute;
    right: 10px;
    top: 10px;
    z-index: 0;
    font-size: 70px;
}
.small-box .small-box-footer {
    background-color: rgba(0,0,0,.1);
    color: rgba(255,255,255,.8);
    display: block;
    padding: 3px 0;
    position: relative;
    text-align: center;
    text-decoration: none;
    z-index: 10;
}
.small-box .small-box-footer:hover {
    background-color: rgba(0,0,0,.15);
    color: #fff;
}
.info-box {
    box-shadow: 0 0 1px rgba(0,0,0,.125), 0 1px 3px rgba(0,0,0,.2);
    border-radius: 0.25rem;
    background: #fff;
    display: flex;
    margin-bottom: 20px;
    min-height: 80px;
    padding: 0.5rem;
    position: relative;
    width: 100%;
}
.info-box .info-box-icon {
    border-radius: 0.25rem;
    align-items: center;
    display: flex;
    font-size: 1.875rem;
    justify-content: center;
    text-align: center;
    width: 70px;
    color: #fff;
}
.info-box .info-box-content {
    flex: 1;
    padding: 0 10px;
}
.info-box .info-box-number {
    display: block;
    font-weight: 700;
    font-size: 1.25rem;
}
.progress {
    background-color: rgba(0,0,0,.125);
    height: 2px;
    border-radius: 0;
}
.progress-description {
    display: block;
    font-size: 0.8rem;
    white-space: nowrap;
}
.bg-primary { background-color: #007bff !important; }
.bg-success { background-color: #28a745 !important; }
.bg-info { background-color: #17a2b8 !important; }
.bg-warning { background-color: #ffc107 !important; }
.bg-danger { background-color: #dc3545 !important; }
.bg-secondary { background-color: #6c757d !important; }
.card-outline {
    border-top: 3px solid;
}
.card-outline.card-primary { border-top-color: #007bff; }
.card-outline.card-success { border-top-color: #28a745; }
.card-outline.card-danger { border-top-color: #dc3545; }
.card-outline.card-warning { border-top-color: #ffc107; }
.card-outline.card-info { border-top-color: #17a2b8; }
.card-outline.card-secondary { border-top-color: #6c757d; }
.card-header .card-tools {
    float: right;
}
</style>

<?php 
 include 'footer.php';
?>