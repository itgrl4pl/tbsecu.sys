<?php
include 'header.php';

if(!$adminloggedin) {
    header("location: login.php");
    exit();
}

$logs = mysqli_query($conn, "SELECT * FROM data_tampering_log ORDER BY detected_at DESC LIMIT 50");
?>

<div class="page-wrapper">
    <div class="content">
        <div class="row">
            <div class="col-sm-12">
                <h4 class="page-title">
                    <i class="fa fa-history"></i> Tampering Detection Logs
                    <a href="index.php" class="btn btn-primary float-right">Back to Dashboard</a>
                </h4>
            </div>
        </div>
        
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header bg-danger text-white">
                        <h5 class="mb-0">Data Tampering Attempts</h5>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-bordered">
                                <thead>
                                    <tr>
                                        <th>Time</th>
                                        <th>Table</th>
                                        <th>Record ID</th>
                                        <th>Expected Hash</th>
                                        <th>Actual Hash</th>
                                        <th>IP Address</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php if(mysqli_num_rows($logs) > 0): ?>
                                        <?php while($log = mysqli_fetch_assoc($logs)): ?>
                                        <tr>
                                            <td><?php echo date('Y-m-d H:i:s', strtotime($log['detected_at'])); ?></td>
                                            <td><span class="badge badge-warning"><?php echo $log['table_name']; ?></span></td>
                                            <td><strong><?php echo $log['record_id']; ?></strong></td>
                                            <td><code><?php echo substr($log['expected_hash'], 0, 16); ?>...</code></td>
                                            <td><code><?php echo substr($log['actual_hash'], 0, 16); ?>...</code></td>
                                            <td><?php echo $log['ip_address']; ?></td>
                                        </tr>
                                        <?php endwhile; ?>
                                    <?php else: ?>
                                        <tr>
                                            <td colspan="6" class="text-center">No tampering detected - database is secure!</td>
                                        </tr>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php include 'footer.php'; ?>