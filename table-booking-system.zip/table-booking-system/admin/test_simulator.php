<?php
session_start();
include 'partials/connection.php';
include 'includes/behavior_analysis.php';

if(!isset($_SESSION['adminloggedin']) || $_SESSION['adminloggedin'] !== true) {
    die("Unauthorized access");
}

$message = '';
$test_type = $_GET['type'] ?? '';

// Simulate different test scenarios
switch($test_type) {
    case 'new_ip':
        // Simulate login from new IP
        $_SERVER['REMOTE_ADDR'] = '192.168.1.' . rand(100, 200);
        $_SERVER['HTTP_USER_AGENT'] = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36';
        
        $analyzer = new AdminBehaviorAnalysis($conn, $_SESSION['adminuserId']);
        $analyzer->trackLogin();
        $message = "New IP login simulated! Check security dashboard.";
        break;
        
    case 'unusual_hour':
        // Simulate login at 3 AM
        $_SERVER['REMOTE_ADDR'] == $_SERVER['REMOTE_ADDR'];
        $_SERVER['HTTP_USER_AGENT'] == $_SERVER['HTTP_USER_AGENT'];
        
        // Manually insert a login with 3 AM timestamp
        $admin_id = $_SESSION['adminuserId'];
        $ip = $_SERVER['REMOTE_ADDR'];
        $ua = $_SERVER['HTTP_USER_AGENT'];
        $hour = 3; // 3 AM
        
        mysqli_query($conn, "INSERT INTO admin_behavior (admin_id, ip_address, user_agent, login_hour, login_day, login_date, login_time) 
                             VALUES ('$admin_id', '$ip', '$ua', '$hour', '1', CURDATE(), NOW())");
        
        // This will trigger unusual hour alert
        $analyzer = new AdminBehaviorAnalysis($conn, $admin_id);
        $analyzer->trackLogin(); // This will detect the unusual hour
        $message = "3 AM login simulated! Check security dashboard for unusual hour alert.";
        break;
        
    case 'rapid_login':
        // Simulate 4 rapid logins in 1 minute
        $admin_id = $_SESSION['adminuserId'];
        $ip = $_SERVER['REMOTE_ADDR'];
        $ua = $_SERVER['HTTP_USER_AGENT'];
        $hour = date('H');
        $day = date('w');
        
        for($i = 0; $i < 4; $i++) {
            $time = date('Y-m-d H:i:s', strtotime("-$i minutes"));
            mysqli_query($conn, "INSERT INTO admin_behavior (admin_id, ip_address, user_agent, login_hour, login_day, login_date, login_time) 
                                 VALUES ('$admin_id', '$ip', '$ua', '$hour', '$day', CURDATE(), '$time')");
        }
        
        // Check for rapid login alert
        $analyzer = new AdminBehaviorAnalysis($conn, $admin_id);
        $analyzer->trackLogin(); // This will detect rapid logins
        $message = " 4 rapid logins simulated! Check security dashboard for rapid login alert.";
        break;
        
    case 'brute_force':
        // Simulate 5 failed login attempts
        $ip = $_SERVER['REMOTE_ADDR'];
        $ua = $_SERVER['HTTP_USER_AGENT'];
        
        for($i = 0; $i < 5; $i++) {
            mysqli_query($conn, "INSERT INTO admin_login_history (admin_id, ip_address, user_agent, status, login_time) 
                                 VALUES ('0', '$ip', '$ua', 'failed', NOW())");
        }
        
        // Check for brute force alert
        $analyzer = new AdminBehaviorAnalysis($conn, 0);
        $analyzer->trackFailedLogin('test_user');
        $message = " 5 failed login attempts simulated! Check security dashboard for brute force alert.";
        break;
        
    case 'clear_alerts':
        // Mark all alerts as read
        mysqli_query($conn, "UPDATE security_alerts SET is_read = 1");
        $message = " All alerts marked as read.";
        break;
        
    case 'generate_all':
        // Run all tests at once
        // New IP
        $_SERVER['REMOTE_ADDR'] = '192.168.1.' . rand(100, 200);
        $analyzer = new AdminBehaviorAnalysis($conn, $_SESSION['adminuserId']);
        $analyzer->trackLogin();
        
        // Unusual hour
        $admin_id = $_SESSION['adminuserId'];
        $ip = $_SERVER['REMOTE_ADDR'];
        $ua = $_SERVER['HTTP_USER_AGENT'];
        mysqli_query($conn, "INSERT INTO admin_behavior (admin_id, ip_address, user_agent, login_hour, login_day, login_date, login_time) 
                             VALUES ('$admin_id', '$ip', '$ua', '3', '1', CURDATE(), NOW())");
        
        // Rapid logins
        for($i = 0; $i < 4; $i++) {
            $time = date('Y-m-d H:i:s', strtotime("-$i minutes"));
            mysqli_query($conn, "INSERT INTO admin_behavior (admin_id, ip_address, user_agent, login_hour, login_day, login_date, login_time) 
                                 VALUES ('$admin_id', '$ip', '$ua', '" . date('H') . "', '" . date('w') . "', CURDATE(), '$time')");
        }
        
        $message = " All test data generated! Check security dashboard for multiple alerts.";
        break;
        
    default:
        $message = "Please select a test type.";
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Security Test Simulator</title>
    <link rel="stylesheet" href="assets/css/bootstrap.min.css">
</head>
<body>
    <div class="container mt-5">
        <div class="row">
            <div class="col-md-8 offset-md-2">
                <div class="card">
                    <div class="card-header bg-primary text-white">
                        <h3> Security Test Simulator</h3>
                    </div>
                    <div class="card-body">
                        
                        <?php if($message): ?>
                            <div class="alert alert-info"><?php echo $message; ?></div>
                        <?php endif; ?>
                        
                        <div class="row">
                            <div class="col-md-6">
                                <h5>Quick Test Buttons:</h5>
                                <a href="?type=new_ip" class="btn btn-info btn-block mb-2"> Test New IP Detection</a>
                                <a href="?type=unusual_hour" class="btn btn-warning btn-block mb-2"> Test Unusual Hour (3 AM)</a>
                                <a href="?type=rapid_login" class="btn btn-danger btn-block mb-2"> Test Rapid Logins</a>
                                <a href="?type=brute_force" class="btn btn-danger btn-block mb-2"> Test Brute Force</a>
                                <a href="?type=generate_all" class="btn btn-success btn-block mb-2"> Generate All Test Data</a>
                                <a href="?type=clear_alerts" class="btn btn-secondary btn-block mb-2"> Clear All Alerts</a>
                            </div>
                            <div class="col-md-6">
                                <h5>Check Results:</h5>
                                <a href="index.php" class="btn btn-primary btn-block mb-2"> View Security Dashboard</a>
                                <a href="ajax_security_logs.php" class="btn btn-info btn-block mb-2" target="_blank"> View Logs</a>
                                <a href="ajax_security_alerts.php" class="btn btn-warning btn-block mb-2" target="_blank"> View Alerts</a>
                                <button onclick="location.reload()" class="btn btn-secondary btn-block"> Refresh Page</button>
                            </div>
                        </div>
                        
                        <hr>
                        
                        <h5>What to expect:</h5>
                        <table class="table table-bordered">
                            <tr>
                                <th>Test</th>
                                <th>Expected Alert</th>
                            </tr>
                            <tr>
                                <td>New IP</td>
                                <td><span class="badge badge-info">New IP detected</span> in dashboard</td>
                            </tr>
                            <tr>
                                <td>Unusual Hour</td>
                                <td><span class="badge badge-warning">Unusual login hour</span> alert</td>
                            </tr>
                            <tr>
                                <td>Rapid Login</td>
                                <td><span class="badge badge-danger">Rapid login</span> high severity alert</td>
                            </tr>
                            <tr>
                                <td>Brute Force</td>
                                <td><span class="badge badge-danger">Brute force attack</span> alert</td>
                            </tr>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>
</html>