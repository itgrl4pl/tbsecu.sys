<?php
session_start();
include 'partials/connection.php';
include 'includes/database_security.php';

if(!isset($_SESSION['adminloggedin']) || $_SESSION['adminloggedin'] !== true) {
    die("Unauthorized");
}

$dbSecurity = new DatabaseSecurity($conn);
$dbSecurity->fullScan();

header("location: index.php");
exit();
?>