<?php
include 'header.php';
include 'includes/audit_trail.php';

if(!$adminloggedin) {
    header("location: login.php");
    exit();
}

$audit = new AuditTrail($conn);
$message = '';
$message_type = '';

if(isset($_GET['action'])) {
    switch($_GET['action']) {
        case 'create_test':
            // Simulate creating a booking
            $audit->logChange('tbl_booking', 'INSERT', rand(1000, 9999), null, ['name' => 'Test Customer', 'status' => 'new']);
            $message = "✅ Test INSERT logged";
            $message_type = 'success';
            break;
            
        case 'update_test':
            // Simulate updating a booking
            $audit->logChange('tbl_booking', 'UPDATE', 123, ['name' => 'Old Name'], ['name' => 'New Name']);
            $message = "✅ Test UPDATE logged";
            $message_type = 'success';
            break;
            
        case 'delete_test':
            // Simulate deleting a booking
            $audit->logChange('tbl_booking', 'DELETE', 123, ['name' => 'Deleted Customer'], null);
            $message = "✅ Test DELETE logged";
            $message_type = 'success';
            break;
            
        case 'mass_delete':
            // Simulate mass deletion (10+ records)
            for($i = 0; $i < 12; $i++) {
                $audit->logChange('tbl_booking', 'DELETE', $i, ['name' => 'Bulk Delete'], null);
            }
            $message = "⚠️ Mass deletion simulated - should trigger anomaly alert";
            $message_type = 'warning';
            break;
            
        case 'rapid_changes':
            // Simulate rapid changes (20+ in 1 minute)
            for($i = 0; $i < 25; $i++) {
                $audit->logChange('tbl_booking', 'UPDATE', $i, null, ['status' => 'changed']);
            }
            $message = "⚠️ Rapid changes simulated - should trigger anomaly alert";
            $message_type = 'warning';
            break;
            
        case 'off_hours':
            // Simulate off-hours access by manipulating time check
            $audit->logChange('tbl_booking', 'SELECT', 0, null, null);
            $message = "🌙 Off-hours access logged - check for alert";
            $message_type = 'info';
            break;
            
        case 'resolve':
            if(isset($_GET['id'])) {
                $audit->resolveAnomaly($_GET['id']);
                $message = "✅ Anomaly resolved";
                $message_type = 'success';
            }
            break;
    }
}

$logs = $audit->getRecentLogs(20);
$anomalies = $audit->getAnomalyAlerts();
$stats = $audit->getStats();
?>

<div class="page-wrapper">
    <div class="content">
        <div class="row">
            <div class="col-sm-12">
                <h4 class="page-title">
                    <i class="fa fa-history"></i> Audit Trail & Anomaly Detection
                    <a href="index.php" class="btn btn-primary float-right">Dashboard</a>
                </h4>
            </div>
        </div>
        
        <?php if($message): ?>
            <div class="alert alert-<?php echo $message_type; ?> alert-dismissible fade show">
                <?php echo $message; ?>
                <button type="button" class="close" data-dismiss="alert">&times;</button>
            </div>
        <?php endif; ?>
        
        <!-- Stats Cards -->
        <div class="row mb-4">
            <div class="col-md-3">
                <div class="card bg-info text-white">
                    <div class="card-body text-center">
                        <h3><?php echo $stats['today_changes']; ?></h3>
                        <small>Changes Today</small>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card bg-primary text-white">
                    <div class="card-body text-center">
                        <h3><?php echo $stats['week_changes']; ?></h3>
                        <small>Changes This Week</small>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card <?php echo $stats['unresolved_anomalies'] > 0 ? 'bg-danger' : 'bg-success'; ?> text-white">
                    <div class="card-body text-center">
                        <h3><?php echo $stats['unresolved_anomalies']; ?></h3>
                        <small>Active Anomalies</small>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card bg-warning text-white">
                    <div class="card-body text-center">
                        <h3><?php echo $stats['most_active']['username'] ?? 'None'; ?></h3>
                        <small>Most Active Admin</small>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- Test Buttons -->
        <div class="row mb-4">
            <div class="col-md-2">
                <a href="?action=create_test" class="btn btn-success btn-block">➕ INSERT</a>
            </div>
            <div class="col-md-2">
                <a href="?action=update_test" class="btn btn-warning btn-block">✏️ UPDATE</a>
            </div>
            <div class="col-md-2">
                <a href="?action=delete_test" class="btn btn-danger btn-block">❌ DELETE</a>
            </div>
            <div class="col-md-2">
                <a href="?action=mass_delete" class="btn btn-danger btn-block" onclick="return confirm('Generate mass deletion?')">📊 Mass Delete</a>
            </div>
            <div class="col-md-2">
                <a href="?action=rapid_changes" class="btn btn-warning btn-block" onclick="return confirm('Generate rapid changes?')">⚡ Rapid Changes</a>
            </div>
            <div class="col-md-2">
                <a href="?action=off_hours" class="btn btn-info btn-block">🌙 Off Hours</a>
            </div>
        </div>
        
        <!-- Anomaly Alerts -->
        <div class="card mb-4">
            <div class="card-header bg-danger text-white">
                <h5 class="mb-0"><i class="fa fa-exclamation-triangle"></i> Active Anomaly Alerts</h5>
            </div>
            <div class="card-body">
                <?php if(empty($anomalies)): ?>
                    <p class="text-success">✅ No anomalies detected</p>
                <?php else: ?>
                    <table class="table table-bordered">
                        <thead>
                            <tr>
                                <th>Time</th>
                                <th>Type</th>
                                <th>Description</th>
                                <th>Severity</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach($anomalies as $a): ?>
                            <tr>
                                <td><?php echo date('H:i:s', strtotime($a['detected_at'])); ?></td>
                                <td><?php echo $a['anomaly_type']; ?></td>
                                <td><?php echo $a['description']; ?></td>
                                <td>
                                    <span class="badge badge-<?php echo $a['severity'] == 'high' ? 'danger' : ($a['severity'] == 'medium' ? 'warning' : 'info'); ?>">
                                        <?php echo ucfirst($a['severity']); ?>
                                    </span>
                                </td>
                                <td>
                                    <a href="?action=resolve&id=<?php echo $a['id']; ?>" class="btn btn-sm btn-success">
                                        <i class="fa fa-check"></i> Resolve
                                    </a>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                <?php endif; ?>
            </div>
        </div>
        
        <!-- Recent Audit Logs -->
        <div class="card">
            <div class="card-header bg-dark text-white">
                <h5 class="mb-0"><i class="fa fa-list"></i> Recent Activity Log</h5>
            </div>
            <div class="card-body">
                <table class="table table-bordered table-striped">
                    <thead>
                        <tr>
                            <th>Time</th>
                            <th>Admin</th>
                            <th>Action</th>
                            <th>Table</th>
                            <th>Record ID</th>
                            <th>Changes</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach($logs as $log): ?>
                        <tr>
                            <td><?php echo date('H:i:s', strtotime($log['change_time'])); ?></td>
                            <td><?php echo $log['username'] ?? 'System'; ?></td>
                            <td>
                                <span class="badge badge-<?php 
                                    echo $log['action'] == 'INSERT' ? 'success' : 
                                        ($log['action'] == 'UPDATE' ? 'warning' : 'danger'); 
                                ?>">
                                    <?php echo $log['action']; ?>
                                </span>
                            </td>
                            <td><?php echo $log['table_name']; ?></td>
                            <td><?php echo $log['record_id']; ?></td>
                            <td>
                                <?php if($log['old_value']): ?>
                                    <small>Old: <?php echo substr($log['old_value'], 0, 50); ?>...</small><br>
                                <?php endif; ?>
                                <small>New: <?php echo substr($log['new_value'], 0, 50); ?>...</small>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
        
        <!-- Instructions -->
        <div class="card mt-4">
            <div class="card-header bg-info text-white">
                <h5 class="mb-0">📋 How to Test</h5>
            </div>
            <div class="card-body">
                <div class="row">
                    <div class="col-md-6">
                        <h6>Basic Tests:</h6>
                        <ul>
                            <li>Click INSERT/UPDATE/DELETE buttons - see logs appear</li>
                            <li>Check the activity log table for your actions</li>
                        </ul>
                        <h6>Anomaly Tests:</h6>
                        <ul>
                            <li><strong>Mass Delete:</strong> Click "Mass Delete" - triggers high severity alert</li>
                            <li><strong>Rapid Changes:</strong> Click "Rapid Changes" - triggers high severity alert</li>
                            <li><strong>Off Hours:</strong> Click "Off Hours" - triggers medium severity alert</li>
                        </ul>
                    </div>
                    <div class="col-md-6">
                        <h6>Expected Results:</h6>
                        <ul>
                            <li> Normal actions: appear in logs, no alerts</li>
                            <li> Mass delete (10+): red alert appears</li>
                            <li> Rapid changes (20+): red alert appears</li>
                            <li> Off-hours (before 6am/after 10pm): yellow alert appears</li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php include 'footer.php'; ?>