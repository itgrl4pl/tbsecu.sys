<?php
if(!class_exists('SessionSecurity')) {

class SessionSecurity {
    private $conn;
    
    public function __construct($conn) {
        $this->conn = $conn;
        
        // Only set ini settings if session hasn't started yet
        if(session_status() === PHP_SESSION_NONE) {
            ini_set('session.cookie_httponly', 1);
            ini_set('session.use_only_cookies', 1);
            ini_set('session.cookie_samesite', 'Strict');
        }
    }
    
    // Create unique fingerprint for this browser
    public function createFingerprint() {
        $fingerprint = [
            'ip' => $_SERVER['REMOTE_ADDR'],
            'user_agent' => $_SERVER['HTTP_USER_AGENT'],
            'accept_language' => $_SERVER['HTTP_ACCEPT_LANGUAGE'] ?? '',
            'accept_encoding' => $_SERVER['HTTP_ACCEPT_ENCODING'] ?? '',
            'connection' => $_SERVER['HTTP_CONNECTION'] ?? '',
            'screen' => $_COOKIE['screen_resolution'] ?? 'unknown'
        ];
        
        return hash('sha256', json_encode($fingerprint) . 'session_salt_2026');
    }
    
    // Initialize session with fingerprint
    public function initSession($admin_id) {
        $fingerprint = $this->createFingerprint();
        
        $_SESSION['admin_id'] = $admin_id;
        $_SESSION['fingerprint'] = $fingerprint;
        $_SESSION['login_time'] = time();
        $_SESSION['last_activity'] = time();
        
        // Store in database
        $ip = $_SERVER['REMOTE_ADDR'];
        $ua = $_SERVER['HTTP_USER_AGENT'];
        mysqli_query($this->conn, "INSERT INTO admin_sessions 
            (admin_id, fingerprint, ip_address, user_agent, login_time) 
            VALUES ('$admin_id', '$fingerprint', '$ip', '$ua', NOW())");
        
        return $fingerprint;
    }
    
    // Verify current session
    public function verifySession() {
        if(!isset($_SESSION['admin_id']) || !isset($_SESSION['fingerprint'])) {
            return false;
        }
        
        // Check fingerprint
        $current = $this->createFingerprint();
        if($current !== $_SESSION['fingerprint']) {
            $this->logHijackAttempt();
            return false;
        }
        
        // Check session timeout (30 minutes)
        if(time() - $_SESSION['last_activity'] > 1800) {
            return false;
        }
        
        // Update last activity
        $_SESSION['last_activity'] = time();
        return true;
    }
    
    // Log potential session hijacking
    private function logHijackAttempt() {
        $admin_id = $_SESSION['admin_id'] ?? 0;
        $ip = $_SERVER['REMOTE_ADDR'];
        $ua = $_SERVER['HTTP_USER_AGENT'];
        
        mysqli_query($this->conn, "INSERT INTO session_hijack_logs 
            (admin_id, attempted_ip, attempted_ua, detected_at) 
            VALUES ('$admin_id', '$ip', '$ua', NOW())");
        
        // Create security alert
        $message = "🚨 Possible session hijacking detected!";
        mysqli_query($this->conn, "INSERT INTO security_alerts 
            (alert_type, message, severity, alert_time) 
            VALUES ('session_hijack', '$message', 'high', NOW())");
    }
    
    // Get active sessions
    public function getActiveSessions() {
        $admin_id = $_SESSION['admin_id'];
        $current_fingerprint = $_SESSION['fingerprint'];
        
        $result = mysqli_query($this->conn, 
            "SELECT * FROM admin_sessions 
             WHERE admin_id = '$admin_id' 
             AND logout_time IS NULL 
             ORDER BY login_time DESC");
        
        $sessions = [];
        while($row = mysqli_fetch_assoc($result)) {
            $row['is_current'] = ($row['fingerprint'] == $current_fingerprint);
            $sessions[] = $row;
        }
        
        return $sessions;
    }
    
    // Terminate other sessions
    public function terminateOtherSessions() {
        $admin_id = $_SESSION['admin_id'];
        $current_fingerprint = $_SESSION['fingerprint'];
        
        mysqli_query($this->conn, 
            "UPDATE admin_sessions 
             SET logout_time = NOW() 
             WHERE admin_id = '$admin_id' 
             AND fingerprint != '$current_fingerprint' 
             AND logout_time IS NULL");
        
        return mysqli_affected_rows($this->conn);
    }
    
    // Get session stats for dashboard
    public function getStats() {
        $stats = [];
        
        $result = mysqli_query($this->conn, "SELECT COUNT(*) as count FROM admin_sessions WHERE logout_time IS NULL");
        $stats['active_sessions'] = mysqli_fetch_assoc($result)['count'];
        
        $result = mysqli_query($this->conn, "SELECT COUNT(*) as count FROM session_hijack_logs WHERE detected_at > DATE_SUB(NOW(), INTERVAL 24 HOUR)");
        $stats['hijack_attempts_24h'] = mysqli_fetch_assoc($result)['count'];
        
        return $stats;
    }
}

}
?>