<?php
if(!class_exists('DatabaseSecurity')) {

class DatabaseSecurity {
    private $conn;
    private $encryption_key;
    private $secret_salt = 'kathi_restaurant_2026_secret';
    
    public function __construct($conn) {
        $this->conn = $conn;
        // Derive encryption key from server info (never stored)
        $this->encryption_key = hash('sha256', $_SERVER['DOCUMENT_ROOT'] . $this->secret_salt, true);
    }
    
    // Encrypt sensitive data
    public function encrypt($data) {
        if(empty($data)) return $data;
        $iv = random_bytes(16);
        $encrypted = openssl_encrypt($data, 'AES-256-CBC', $this->encryption_key, 0, $iv);
        return base64_encode($iv . $encrypted);
    }
    
    // Decrypt sensitive data
    public function decrypt($data) {
        if(empty($data)) return $data;
        $data = base64_decode($data);
        $iv = substr($data, 0, 16);
        $encrypted = substr($data, 16);
        return openssl_decrypt($encrypted, 'AES-256-CBC', $this->encryption_key, 0, $iv);
    }
    
    // Calculate integrity hash for a record
    public function calculateHash($table, $id, $values) {
        $data_string = $table . $id . json_encode($values) . $this->secret_salt;
        return hash('sha256', $data_string);
    }
    
    // Check if a table has been tampered with
    public function checkTampering($table, $id, $values, $stored_hash) {
        $calculated = $this->calculateHash($table, $id, $values);
        
        if($calculated !== $stored_hash) {
            $this->logTampering($table, $id, $stored_hash, $calculated);
            return true;
        }
        return false;
    }
    
    // Log tampering attempts
    private function logTampering($table, $id, $expected, $actual) {
        $ip = $_SERVER['REMOTE_ADDR'];
        $query = "INSERT INTO data_tampering_log (table_name, record_id, expected_hash, actual_hash, detected_at, ip_address) 
                  VALUES ('$table', '$id', '$expected', '$actual', NOW(), '$ip')";
        mysqli_query($this->conn, $query);
        
        // Create security alert
        $message = "🚨 Tampering detected in $table (ID: $id)";
        $alert_query = "INSERT INTO security_alerts (alert_type, message, severity, alert_time) 
                        VALUES ('tampering', '$message', 'high', NOW())";
        mysqli_query($this->conn, $alert_query);
    }
    
    // Scan entire database for tampering
    public function fullScan() {
        $tampered = [];
        
        // Check bookings
        $bookings = mysqli_query($this->conn, "SELECT id, booking_id, name, emailid, mobile, booking_date, integrity_hash FROM tbl_booking");
        if($bookings) {
            while($row = mysqli_fetch_assoc($bookings)) {
                if($row['integrity_hash']) {
                    $values = [
                        'booking_id' => $row['booking_id'],
                        'name' => $row['name'],
                        'email' => $row['emailid'],
                        'mobile' => $row['mobile'],
                        'date' => $row['booking_date']
                    ];
                    
                    $calculated = $this->calculateHash('tbl_booking', $row['id'], $values);
                    
                    if($calculated !== $row['integrity_hash']) {
                        
                        // Check if this tampering was already logged recently
                        $check = mysqli_query($this->conn, 
                            "SELECT id FROM data_tampering_log 
                             WHERE table_name = 'tbl_booking' 
                             AND record_id = '{$row['id']}' 
                             AND detected_at > DATE_SUB(NOW(), INTERVAL 1 HOUR)");
                        
                        if(mysqli_num_rows($check) == 0) {
                            $this->logTampering('tbl_booking', $row['id'], $row['integrity_hash'], $calculated);
                        }
                        
                        $tampered[] = "Booking #{$row['id']}";
                    }
                }
            }
        }
        
        // Check tables
        $tables = mysqli_query($this->conn, "SELECT id, table_no, integrity_hash FROM tbl_table");
        if($tables) {
            while($row = mysqli_fetch_assoc($tables)) {
                if($row['integrity_hash']) {
                    $values = ['table_no' => $row['table_no']];
                    
                    $calculated = $this->calculateHash('tbl_table', $row['id'], $values);
                    
                    if($calculated !== $row['integrity_hash']) {
                        
                        $check = mysqli_query($this->conn, 
                            "SELECT id FROM data_tampering_log 
                             WHERE table_name = 'tbl_table' 
                             AND record_id = '{$row['id']}' 
                             AND detected_at > DATE_SUB(NOW(), INTERVAL 1 HOUR)");
                        
                        if(mysqli_num_rows($check) == 0) {
                            $this->logTampering('tbl_table', $row['id'], $row['integrity_hash'], $calculated);
                        }
                        
                        $tampered[] = "Table #{$row['id']}";
                    }
                }
            }
        }
        
        return $tampered;
    }
    
    // Get tampering stats for dashboard
    public function getStats() {
        $stats = [];
        
        $result = mysqli_query($this->conn, "SELECT COUNT(*) as count FROM data_tampering_log");
        $stats['total_tampering'] = $result ? mysqli_fetch_assoc($result)['count'] : 0;
        
        $result = mysqli_query($this->conn, "SELECT COUNT(*) as count FROM data_tampering_log WHERE detected_at > DATE_SUB(NOW(), INTERVAL 24 HOUR)");
        $stats['last_24h'] = $result ? mysqli_fetch_assoc($result)['count'] : 0;
        
        return $stats;
    }
}

}
?>