<?php
class AdminBehaviorAnalysis {
    private $conn;
    private $admin_id;
    
    public function __construct($conn, $admin_id) {
        $this->conn = $conn;
        $this->admin_id = $admin_id;
    }
    
    // Track successful login
    public function trackLogin() {
        $ip = $_SERVER['REMOTE_ADDR'];
        $user_agent = $_SERVER['HTTP_USER_AGENT'];
        $hour = date('H');
        $day = date('w');
        $login_date = date('Y-m-d');
        
        // Insert login record
        $query = "INSERT INTO admin_behavior (admin_id, ip_address, user_agent, login_hour, login_day, login_date, login_time) 
                  VALUES ('$this->admin_id', '$ip', '$user_agent', '$hour', '$day', '$login_date', NOW())";
        mysqli_query($this->conn, $query);
        
        // Analyze for suspicious patterns
        return $this->analyzePatterns($ip, $hour, $day);
    }
    
    // Track failed login attempt
    public function trackFailedLogin($username) {
        $ip = $_SERVER['REMOTE_ADDR'];
        $user_agent = $_SERVER['HTTP_USER_AGENT'];
        
        $query = "INSERT INTO admin_login_history (admin_id, ip_address, user_agent, status, login_time) 
                  VALUES ('0', '$ip', '$user_agent', 'failed', NOW())";
        mysqli_query($this->conn, $query);
        
        // Check for brute force attempts
        $this->checkBruteForce($ip);
    }
    
    // Check for brute force attempts
    private function checkBruteForce($ip) {
        $check = mysqli_query($this->conn, 
            "SELECT COUNT(*) as attempts FROM admin_login_history 
             WHERE ip_address = '$ip' AND status = 'failed' 
             AND login_time > DATE_SUB(NOW(), INTERVAL 15 MINUTE)");
        
        $result = mysqli_fetch_assoc($check);
        
        if($result['attempts'] >= 5) {
            $message = "🚨 Possible brute force attack from IP: $ip - " . $result['attempts'] . " failed attempts in 15 minutes";
            $this->createAlert('brute_force', $message, 'high');
        }
    }
    
    // Analyze patterns for anomalies
    private function analyzePatterns($current_ip, $current_hour, $current_day) {
        $alerts = [];
        
        // 1. Check for new IP address
        $ip_check = mysqli_query($this->conn, 
            "SELECT COUNT(*) as count FROM admin_behavior 
             WHERE admin_id = '$this->admin_id' AND ip_address = '$current_ip'");
        $ip_result = mysqli_fetch_assoc($ip_check);
        
        if($ip_result['count'] == 1) { // First time with this IP
            $alerts[] = "New IP address detected: " . $current_ip;
            $this->createAlert('new_ip', "New login from IP: $current_ip", 'medium');
        }
        
        // 2. Check for unusual hour
        $hour_check = mysqli_query($this->conn, 
            "SELECT DISTINCT login_hour FROM admin_behavior 
             WHERE admin_id = '$this->admin_id' GROUP BY login_hour");
        
        $usual_hours = [];
        while($row = mysqli_fetch_assoc($hour_check)) {
            $usual_hours[] = $row['login_hour'];
        }
        
        if(!empty($usual_hours) && !in_array($current_hour, $usual_hours)) {
            $alerts[] = "Unusual login hour: " . $current_hour . ":00";
            $this->createAlert('unusual_hour', "Login at unusual hour: $current_hour:00", 'medium');
        }
        
        // 3. Check for rapid logins
        $rapid_check = mysqli_query($this->conn, 
            "SELECT COUNT(*) as count FROM admin_behavior 
             WHERE admin_id = '$this->admin_id' 
             AND login_time > DATE_SUB(NOW(), INTERVAL 5 MINUTE)");
        $rapid_result = mysqli_fetch_assoc($rapid_check);
        
        if($rapid_result['count'] > 3) {
            $alerts[] = "Multiple rapid logins detected!";
            $this->createAlert('rapid_login', "Multiple logins in short period", 'high');
        }
        
        return $alerts;
    }
    
    // Create security alert
    private function createAlert($type, $message, $severity) {
        $query = "INSERT INTO security_alerts (alert_type, message, severity, alert_time) 
                  VALUES ('$type', '$message', '$severity', NOW())";
        mysqli_query($this->conn, $query);
    }
    
    // Get today's stats for dashboard
    public function getTodayStats() {
        $today = date('Y-m-d');
        $stats = [];
        
        // Today's logins
        $logins = mysqli_query($this->conn, 
            "SELECT COUNT(*) as count FROM admin_behavior 
             WHERE admin_id = '$this->admin_id' AND DATE(login_time) = '$today'");
        $stats['today_logins'] = mysqli_fetch_assoc($logins)['count'];
        
        // Total logins
        $total = mysqli_query($this->conn, 
            "SELECT COUNT(*) as count FROM admin_behavior WHERE admin_id = '$this->admin_id'");
        $stats['total_logins'] = mysqli_fetch_assoc($total)['count'];
        
        // Unique IPs
        $ips = mysqli_query($this->conn, 
            "SELECT COUNT(DISTINCT ip_address) as count FROM admin_behavior WHERE admin_id = '$this->admin_id'");
        $stats['unique_ips'] = mysqli_fetch_assoc($ips)['count'];
        
        // Unread alerts count
        $alerts = mysqli_query($this->conn, 
            "SELECT COUNT(*) as count FROM security_alerts WHERE is_read = 0");
        $stats['unread_alerts'] = mysqli_fetch_assoc($alerts)['count'];
        
        return $stats;
    }
    
    // Get recent alerts for dashboard
    public function getRecentAlerts($limit = 5) {
        $alerts = [];
        $query = mysqli_query($this->conn, 
            "SELECT * FROM security_alerts ORDER BY alert_time DESC LIMIT $limit");
        
        while($row = mysqli_fetch_assoc($query)) {
            $alerts[] = $row;
        }
        return $alerts;
    }
}
?>