<?php
if(!class_exists('AuditTrail')) {

class AuditTrail {
    private $conn;
    
    public function __construct($conn) {
        $this->conn = $conn;
    }
    
    // Log any database change
    public function logChange($table, $action, $record_id, $old_data = null, $new_data = null) {
        $admin_id = $_SESSION['admin_id'] ?? 0;
        $ip = $_SERVER['REMOTE_ADDR'];
        
        $old_json = $old_data ? json_encode($old_data) : '';
        $new_json = $new_data ? json_encode($new_data) : '';
        
        $query = "INSERT INTO audit_log 
                  (admin_id, table_name, action, record_id, old_value, new_value, ip_address, change_time) 
                  VALUES 
                  ('$admin_id', '$table', '$action', '$record_id', '$old_json', '$new_json', '$ip', NOW())";
        
        mysqli_query($this->conn, $query);
        
        // Check for suspicious patterns
        $this->detectAnomalies($admin_id, $action, $table);
    }
    
    // Detect suspicious activity
    private function detectAnomalies($admin_id, $action, $table) {
        
        // 1. Mass deletion detection (10+ records in 5 minutes)
        if($action == 'DELETE') {
            $count = mysqli_query($this->conn,
                "SELECT COUNT(*) as cnt FROM audit_log 
                 WHERE admin_id = '$admin_id' 
                 AND action = 'DELETE' 
                 AND change_time > DATE_SUB(NOW(), INTERVAL 5 MINUTE)");
            $result = mysqli_fetch_assoc($count);
            
            if($result['cnt'] >= 10) {
                $this->createAnomalyAlert(
                    'mass_deletion',
                    "Mass deletion detected: " . $result['cnt'] . " records deleted in 5 minutes",
                    'high'
                );
            }
        }
        
        // 2. Off-hours access (before 6am or after 10pm)
        $hour = date('H');
        if($hour < 6 || $hour > 22) {
            $this->createAnomalyAlert(
                'off_hours',
                "Admin activity detected at " . $hour . ":00 (" . date('h:i A') . ")",
                'medium'
            );
        }
        
        // 3. Rapid changes (20+ changes in 1 minute)
        $rapid = mysqli_query($this->conn,
            "SELECT COUNT(*) as cnt FROM audit_log 
             WHERE admin_id = '$admin_id' 
             AND change_time > DATE_SUB(NOW(), INTERVAL 1 MINUTE)");
        $result = mysqli_fetch_assoc($rapid);
        
        if($result['cnt'] >= 20) {
            $this->createAnomalyAlert(
                'rapid_changes',
                "Unusual activity: " . $result['cnt'] . " changes in 1 minute",
                'high'
            );
        }
        
        // 4. Sensitive table access
        $sensitive_tables = ['users', 'admin_behavior', 'audit_log'];
        if(in_array($table, $sensitive_tables) && $action == 'DELETE') {
            $this->createAnomalyAlert(
                'sensitive_access',
                "Delete operation on sensitive table: $table",
                'high'
            );
        }
    }
    
    // Create anomaly alert
    private function createAnomalyAlert($type, $description, $severity) {
        $query = "INSERT INTO anomaly_alerts (anomaly_type, description, severity, detected_at) 
                  VALUES ('$type', '$description', '$severity', NOW())";
        mysqli_query($this->conn, $query);
        
        // Also add to security alerts
        $alert_query = "INSERT INTO security_alerts (alert_type, message, severity, alert_time) 
                        VALUES ('anomaly', '$description', '$severity', NOW())";
        mysqli_query($this->conn, $alert_query);
    }
    
    // Get recent audit logs
    public function getRecentLogs($limit = 50) {
        $logs = [];
        $query = mysqli_query($this->conn, 
            "SELECT a.*, u.username 
             FROM audit_log a
             LEFT JOIN users u ON a.admin_id = u.id
             ORDER BY a.change_time DESC 
             LIMIT $limit");
        
        while($row = mysqli_fetch_assoc($query)) {
            $logs[] = $row;
        }
        return $logs;
    }
    
    // Get anomaly alerts
    public function getAnomalyAlerts($unresolved_only = true) {
        $alerts = [];
        $where = $unresolved_only ? "WHERE is_resolved = 0" : "";
        
        $query = mysqli_query($this->conn, 
            "SELECT * FROM anomaly_alerts 
             $where 
             ORDER BY detected_at DESC 
             LIMIT 20");
        
        while($row = mysqli_fetch_assoc($query)) {
            $alerts[] = $row;
        }
        return $alerts;
    }
    
    // Get stats for dashboard
    public function getStats() {
        $stats = [];
        
        // Total changes today
        $today = mysqli_query($this->conn,
            "SELECT COUNT(*) as count FROM audit_log 
             WHERE DATE(change_time) = CURDATE()");
        $stats['today_changes'] = mysqli_fetch_assoc($today)['count'];
        
        // Total changes this week
        $week = mysqli_query($this->conn,
            "SELECT COUNT(*) as count FROM audit_log 
             WHERE YEARWEEK(change_time) = YEARWEEK(NOW())");
        $stats['week_changes'] = mysqli_fetch_assoc($week)['count'];
        
        // Unresolved anomalies
        $anomalies = mysqli_query($this->conn,
            "SELECT COUNT(*) as count FROM anomaly_alerts WHERE is_resolved = 0");
        $stats['unresolved_anomalies'] = mysqli_fetch_assoc($anomalies)['count'];
        
        // Most active admin
        $active = mysqli_query($this->conn,
            "SELECT u.username, COUNT(*) as actions 
             FROM audit_log a
             JOIN users u ON a.admin_id = u.id
             WHERE a.change_time > DATE_SUB(NOW(), INTERVAL 7 DAY)
             GROUP BY a.admin_id
             ORDER BY actions DESC
             LIMIT 1");
        $stats['most_active'] = mysqli_fetch_assoc($active);
        
        return $stats;
    }
    
    // Resolve anomaly alert
    public function resolveAnomaly($id) {
        mysqli_query($this->conn, "UPDATE anomaly_alerts SET is_resolved = 1 WHERE id = '$id'");
    }
}

}
?>