<?php
if(!class_exists('ActionApproval')) {

class ActionApproval {
    private $conn;
    
    public function __construct($conn) {
        $this->conn = $conn;
    }
    
    // Request approval for a critical action
    public function requestApproval($action_type, $details) {
        $admin_id = $_SESSION['admin_id'] ?? 0;
        
        // Generate unique token and 6-digit code
        $token = bin2hex(random_bytes(32));
        $code = rand(100000, 999999);
        $expires_at = date('Y-m-d H:i:s', strtotime('+15 minutes'));
        
        $details_json = json_encode($details);
        
        $query = "INSERT INTO pending_approvals 
                  (admin_id, action_type, action_details, approval_token, approval_code, created_at, expires_at) 
                  VALUES 
                  ('$admin_id', '$action_type', '$details_json', '$token', '$code', NOW(), '$expires_at')";
        
        if(mysqli_query($this->conn, $query)) {
            $id = mysqli_insert_id($this->conn);
            
            // Log the approval request
            $this->logApprovalRequest($admin_id, $action_type, $id);
            
            return [
                'success' => true,
                'approval_id' => $id,
                'token' => $token,
                'code' => $code,
                'expires_at' => $expires_at
            ];
        }
        
        return ['success' => false, 'message' => 'Failed to create approval request'];
    }
    
    // Verify approval code
    public function verifyApproval($token, $code) {
        // Clean up expired requests first
        $this->cleanupExpired();
        
        $query = mysqli_query($this->conn, 
            "SELECT * FROM pending_approvals 
             WHERE approval_token = '$token' 
             AND status = 'pending'
             AND expires_at > NOW()");
        
        if(mysqli_num_rows($query) > 0) {
            $approval = mysqli_fetch_assoc($query);
            
            if($approval['approval_code'] == $code) {
                // Code matches - approve it
                $approver_id = $_SESSION['admin_id'] ?? 0;
                
                mysqli_query($this->conn, 
                    "UPDATE pending_approvals 
                     SET status = 'approved', approved_at = NOW(), approved_by = '$approver_id'
                     WHERE id = '{$approval['id']}'");
                
                return [
                    'success' => true,
                    'action_type' => $approval['action_type'],
                    'action_details' => json_decode($approval['action_details'], true)
                ];
            } else {
                return ['success' => false, 'message' => 'Invalid approval code'];
            }
        }
        
        return ['success' => false, 'message' => 'Approval request not found or expired'];
    }
    
    // Reject approval request
    public function rejectApproval($token) {
        mysqli_query($this->conn, 
            "UPDATE pending_approvals 
             SET status = 'rejected' 
             WHERE approval_token = '$token'");
        
        return ['success' => true, 'message' => 'Request rejected'];
    }
    
    // Get pending approvals for current admin
    public function getPendingApprovals() {
        $this->cleanupExpired();
        
        $admin_id = $_SESSION['admin_id'] ?? 0;
        
        $query = mysqli_query($this->conn, 
            "SELECT pa.*, u.username as requester_name 
             FROM pending_approvals pa
             JOIN users u ON pa.admin_id = u.id
             WHERE pa.status = 'pending'
             AND pa.expires_at > NOW()
             AND pa.admin_id != '$admin_id'
             ORDER BY pa.created_at DESC");
        
        $approvals = [];
        while($row = mysqli_fetch_assoc($query)) {
            $row['action_details'] = json_decode($row['action_details'], true);
            $approvals[] = $row;
        }
        
        return $approvals;
    }
    
    // Get my approval requests
    public function getMyRequests() {
        $this->cleanupExpired();
        
        $admin_id = $_SESSION['admin_id'] ?? 0;
        
        $query = mysqli_query($this->conn, 
            "SELECT * FROM pending_approvals 
             WHERE admin_id = '$admin_id'
             ORDER BY created_at DESC
             LIMIT 20");
        
        $requests = [];
        while($row = mysqli_fetch_assoc($query)) {
            $row['action_details'] = json_decode($row['action_details'], true);
            $requests[] = $row;
        }
        
        return $requests;
    }
    
    // Clean up expired requests
    private function cleanupExpired() {
        mysqli_query($this->conn, 
            "UPDATE pending_approvals 
             SET status = 'expired' 
             WHERE status = 'pending' 
             AND expires_at < NOW()");
    }
    
    // Log approval request (for audit trail)
    private function logApprovalRequest($admin_id, $action_type, $approval_id) {
        $message = "Approval requested for $action_type (ID: $approval_id)";
        
        // Add to security_alerts (medium severity)
        $alert_query = "INSERT INTO security_alerts (alert_type, message, severity, alert_time) 
                        VALUES ('approval_request', '$message', 'medium', NOW())";
        mysqli_query($this->conn, $alert_query);
    }
    
    // Get stats for dashboard
    public function getStats() {
        $stats = [];
        
        // Pending approvals
        $pending = mysqli_query($this->conn,
            "SELECT COUNT(*) as count FROM pending_approvals 
             WHERE status = 'pending' AND expires_at > NOW()");
        $stats['pending_approvals'] = mysqli_fetch_assoc($pending)['count'];
        
        // Total today
        $today = mysqli_query($this->conn,
            "SELECT COUNT(*) as count FROM pending_approvals 
             WHERE DATE(created_at) = CURDATE()");
        $stats['today_requests'] = mysqli_fetch_assoc($today)['count'];
        
        // Approval rate
        $total = mysqli_query($this->conn, "SELECT COUNT(*) as count FROM pending_approvals");
        $approved = mysqli_query($this->conn, "SELECT COUNT(*) as count FROM pending_approvals WHERE status = 'approved'");
        $total_count = mysqli_fetch_assoc($total)['count'];
        $approved_count = mysqli_fetch_assoc($approved)['count'];
        
        $stats['approval_rate'] = $total_count > 0 ? round(($approved_count / $total_count) * 100) : 0;
        
        return $stats;
    }
}

}
?>