<?php
session_start();
include 'partials/connection.php';

if(!isset($_SESSION['adminloggedin']) || $_SESSION['adminloggedin'] !== true) {
    echo "Unauthorized access";
    exit();
}

$user_id = $_SESSION['adminuserId'];

// Get all admin behavior logs
$logs_query = mysqli_query($conn, 
    "SELECT * FROM admin_behavior 
     WHERE admin_id = '$user_id' 
     ORDER BY login_time DESC 
     LIMIT 50");

if(mysqli_num_rows($logs_query) > 0) {
    echo '<table class="table table-striped">';
    echo '<thead><tr><th>Date/Time</th><th>IP Address</th><th>Hour</th><th>Day</th></tr></thead>';
    echo '<tbody>';
    while($log = mysqli_fetch_assoc($logs_query)) {
        $day_name = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'][$log['login_day']];
        echo '<tr>';
        echo '<td>' . date('Y-m-d H:i:s', strtotime($log['login_time'])) . '</td>';
        echo '<td><code>' . $log['ip_address'] . '</code></td>';
        echo '<td>' . $log['login_hour'] . ':00</td>';
        echo '<td>' . $day_name . '</td>';
        echo '</tr>';
    }
    echo '</tbody></table>';
} else {
    echo '<p class="text-muted">No logs found.</p>';
}
?>