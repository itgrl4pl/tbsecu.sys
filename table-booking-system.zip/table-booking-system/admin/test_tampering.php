<?php
include 'header.php';

if(!$adminloggedin) {
    header("location: login.php");
    exit();
}

include 'includes/database_security.php';
$dbSecurity = new DatabaseSecurity($conn);

// Handle test actions
$message = '';
$message_type = '';

if(isset($_GET['action'])) {
    switch($_GET['action']) {
        case 'make_booking':
            // Create a test booking
            $test_id = mt_rand(10000000, 99999999);
            $test_name = "Test Customer " . rand(1, 100);
            $test_email = "test" . rand(1, 100) . "@email.com";
            $test_phone = "98765" . rand(10000, 99999);
            
            // Calculate hash
            $values = [
                'booking_id' => $test_id,
                'name' => $test_name,
                'email' => $test_email,
                'mobile' => $test_phone,
                'date' => date('Y-m-d')
            ];
            $hash = $dbSecurity->calculateHash('tbl_booking', 'new', $values);
            
            $insert = mysqli_query($conn, "INSERT INTO tbl_booking 
                (booking_id, name, emailid, mobile, booking_date, booking_time, adults, childrens, ip_address, booking_status, integrity_hash, created_at) 
                VALUES 
                ('$test_id', '$test_name', '$test_email', '$test_phone', CURDATE(), '19:00:00', 2, 0, '127.0.0.1', 0, '$hash', NOW())");
            
            if($insert) {
                $message = "✅ Test booking created with ID: <strong>$test_id</strong>";
                $message_type = 'success';
            } else {
                $message = "❌ Failed to create test booking: " . mysqli_error($conn);
                $message_type = 'danger';
            }
            break;
            
        case 'tamper_booking':
            // Find a booking to tamper with
            $find = mysqli_query($conn, "SELECT id, booking_id, name FROM tbl_booking WHERE integrity_hash IS NOT NULL ORDER BY id DESC LIMIT 1");
            if(mysqli_num_rows($find) > 0) {
                $booking = mysqli_fetch_assoc($find);
                $booking_id = $booking['booking_id'];
                
                // Change the name (simulate tampering)
                $new_name = $booking['name'] . " (TAMPERED)";
                mysqli_query($conn, "UPDATE tbl_booking SET name = '$new_name' WHERE booking_id = '$booking_id'");
                
                $message = "⚠️ Tampered with booking #$booking_id - Name changed to: $new_name";
                $message_type = 'warning';
            } else {
                $message = "❌ No bookings found with integrity hash. Create a test booking first.";
                $message_type = 'danger';
            }
            break;
            
        case 'scan':
            // Run tamper detection scan
            $tampered = $dbSecurity->fullScan();
            if(!empty($tampered)) {
                $message = "🔍 Scan complete! Found " . count($tampered) . " tampered records.";
                $message_type = 'danger';
            } else {
                $message = "✅ Scan complete! No tampering detected.";
                $message_type = 'success';
            }
            break;
            
        case 'clear_logs':
            // Clear tampering logs (for testing)
            mysqli_query($conn, "DELETE FROM data_tampering_log");
            mysqli_query($conn, "UPDATE security_alerts SET is_read = 1 WHERE alert_type = 'tampering'");
            $message = "🧹 Test logs cleared.";
            $message_type = 'info';
            break;
    }
}

// Get stats
$stats = $dbSecurity->getStats();
$tampered = $dbSecurity->fullScan();
?>

<div class="page-wrapper">
    <div class="content">
        <div class="row">
            <div class="col-sm-12">
                <h4 class="page-title">
                    <i class="fa fa-flask"></i> Tamper Detection Test Simulator
                    <a href="index.php" class="btn btn-primary float-right">Back to Dashboard</a>
                </h4>
            </div>
        </div>
        
        <?php if($message): ?>
            <div class="alert alert-<?php echo $message_type; ?> alert-dismissible fade show">
                <?php echo $message; ?>
                <button type="button" class="close" data-dismiss="alert">&times;</button>
            </div>
        <?php endif; ?>
        
        <!-- Current Status Cards -->
        <div class="row">
            <div class="col-md-4">
                <div class="card bg-info text-white">
                    <div class="card-body text-center">
                        <h3><?php echo $stats['total_tampering']; ?></h3>
                        <small>Total Tampering Attempts</small>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card bg-warning text-white">
                    <div class="card-body text-center">
                        <h3><?php echo $stats['last_24h']; ?></h3>
                        <small>Last 24 Hours</small>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card <?php echo empty($tampered) ? 'bg-success' : 'bg-danger'; ?> text-white">
                    <div class="card-body text-center">
                        <h3><?php echo count($tampered); ?></h3>
                        <small>Currently Tampered</small>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- Test Steps -->
        <div class="row mt-4">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header bg-primary text-white">
                        <h5 class="mb-0">🧪 Test Steps (Follow in Order)</h5>
                    </div>
                    <div class="card-body">
                        <div class="row">
                            <div class="col-md-3">
                                <div class="card h-100 <?php echo isset($_GET['action']) && $_GET['action'] == 'make_booking' ? 'border-success' : ''; ?>">
                                    <div class="card-body text-center">
                                        <h1 class="mb-3">1️⃣</h1>
                                        <h5>Create Test Booking</h5>
                                        <p class="text-muted small">Creates a booking with integrity hash</p>
                                        <a href="?action=make_booking" class="btn btn-success btn-block">
                                            <i class="fa fa-plus"></i> Create Test Booking
                                        </a>
                                    </div>
                                </div>
                            </div>
                            
                            <div class="col-md-3">
                                <div class="card h-100 <?php echo isset($_GET['action']) && $_GET['action'] == 'tamper_booking' ? 'border-warning' : ''; ?>">
                                    <div class="card-body text-center">
                                        <h1 class="mb-3">2️⃣</h1>
                                        <h5>Tamper with Booking</h5>
                                        <p class="text-muted small">Simulates someone modifying database directly</p>
                                        <a href="?action=tamper_booking" class="btn btn-warning btn-block" onclick="return confirm('This will modify a booking to simulate tampering. Continue?')">
                                            <i class="fa fa-exclamation-triangle"></i> Tamper Booking
                                        </a>
                                    </div>
                                </div>
                            </div>
                            
                            <div class="col-md-3">
                                <div class="card h-100 <?php echo isset($_GET['action']) && $_GET['action'] == 'scan' ? 'border-info' : ''; ?>">
                                    <div class="card-body text-center">
                                        <h1 class="mb-3">3️⃣</h1>
                                        <h5>Scan for Tampering</h5>
                                        <p class="text-muted small">Detects any modified records</p>
                                        <a href="?action=scan" class="btn btn-info btn-block">
                                            <i class="fa fa-search"></i> Run Scan
                                        </a>
                                    </div>
                                </div>
                            </div>
                            
                            <div class="col-md-3">
                                <div class="card h-100">
                                    <div class="card-body text-center">
                                        <h1 class="mb-3">4️⃣</h1>
                                        <h5>Check Dashboard</h5>
                                        <p class="text-muted small">View alerts and tampering logs</p>
                                        <a href="index.php" class="btn btn-primary btn-block">
                                            <i class="fa fa-dashboard"></i> View Dashboard
                                        </a>
                                        <a href="tampering_logs.php" class="btn btn-secondary btn-block mt-2">
                                            <i class="fa fa-history"></i> View Logs
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- Manual Test Instructions -->
        <div class="row mt-4">
            <div class="col-md-6">
                <div class="card">
                    <div class="card-header bg-secondary text-white">
                        <h5 class="mb-0">📝 Manual Test (phpMyAdmin)</h5>
                    </div>
                    <div class="card-body">
                        <ol>
                            <li>Open phpMyAdmin</li>
                            <li>Go to <code>kathi_db</code> → <code>tbl_booking</code></li>
                            <li>Find a booking with an <code>integrity_hash</code> value</li>
                            <li>Edit the <code>name</code> field to something else</li>
                            <li>Click "Go" to save</li>
                            <li>Refresh this page or admin dashboard</li>
                            <li>Red alert should appear showing tampering detected</li>
                        </ol>
                        <a href="http://localhost/phpmyadmin" target="_blank" class="btn btn-warning">
                            <i class="fa fa-external-link"></i> Open phpMyAdmin
                        </a>
                    </div>
                </div>
            </div>
            
            <div class="col-md-6">
                <div class="card">
                    <div class="card-header bg-danger text-white">
                        <h5 class="mb-0">⚠️ Expected Results</h5>
                    </div>
                    <div class="card-body">
                        <table class="table">
                            <tr>
                                <th>After Step 1</th>
                                <td><span class="badge badge-success">Booking created</span></td>
                            </tr>
                            <tr>
                                <th>After Step 2</th>
                                <td><span class="badge badge-warning">Data tampered</span></td>
                            </tr>
                            <tr>
                                <th>After Step 3</th>
                                <td>
                                    <span class="badge badge-danger">Tampering detected!</span><br>
                                    <small>Check admin dashboard for red alert</small>
                                </td>
                            </tr>
                            <tr>
                                <th>View Logs</th>
                                <td>
                                    <span class="badge badge-info">Click "View Tampering Logs"</span><br>
                                    <small>Shows exactly what was changed</small>
                                </td>
                            </tr>
                        </table>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- Quick Actions -->
        <div class="row mt-4">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header bg-dark text-white">
                        <h5 class="mb-0">⚡ Quick Actions</h5>
                    </div>
                    <div class="card-body">
                        <a href="?action=make_booking" class="btn btn-success">➕ New Test Booking</a>
                        <a href="?action=tamper_booking" class="btn btn-warning">🔨 Tamper Last Booking</a>
                        <a href="?action=scan" class="btn btn-info">🔍 Scan Now</a>
                        <a href="?action=clear_logs" class="btn btn-secondary">🧹 Clear Test Logs</a>
                        <a href="tampering_logs.php" class="btn btn-primary">📋 View All Logs</a>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- Recent Tampering Logs Preview -->
        <div class="row mt-4">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header bg-danger text-white">
                        <h5 class="mb-0"><i class="fa fa-history"></i> Recent Tampering Attempts</h5>
                    </div>
                    <div class="card-body">
                        <?php
                        $logs = mysqli_query($conn, "SELECT * FROM data_tampering_log ORDER BY detected_at DESC LIMIT 5");
                        if(mysqli_num_rows($logs) > 0):
                        ?>
                        <table class="table table-bordered">
                            <thead>
                                <tr>
                                    <th>Time</th>
                                    <th>Table</th>
                                    <th>Record ID</th>
                                    <th>IP Address</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php while($log = mysqli_fetch_assoc($logs)): ?>
                                <tr>
                                    <td><?php echo date('H:i:s', strtotime($log['detected_at'])); ?></td>
                                    <td><?php echo $log['table_name']; ?></td>
                                    <td><?php echo $log['record_id']; ?></td>
                                    <td><?php echo $log['ip_address']; ?></td>
                                </tr>
                                <?php endwhile; ?>
                            </tbody>
                        </table>
                        <?php else: ?>
                        <p class="text-muted">No tampering attempts detected yet.</p>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php include 'footer.php'; ?>