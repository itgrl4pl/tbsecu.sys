<?php
session_start();
include 'partials/connection.php';

if(!isset($_SESSION['adminloggedin']) || $_SESSION['adminloggedin'] !== true) {
    echo "Unauthorized access";
    exit();
}

// Get all security alerts
$alerts_query = mysqli_query($conn, 
    "SELECT * FROM security_alerts 
     ORDER BY alert_time DESC 
     LIMIT 50");

if(mysqli_num_rows($alerts_query) > 0) {
    echo '<table class="table table-striped">';
    echo '<thead><tr><th>Time</th><th>Type</th><th>Message</th><th>Severity</th><th>Status</th></tr></thead>';
    echo '<tbody>';
    while($alert = mysqli_fetch_assoc($alerts_query)) {
        $severity_class = $alert['severity'] == 'high' ? 'danger' : ($alert['severity'] == 'medium' ? 'warning' : 'info');
        $status = $alert['is_read'] ? 'Read' : '<span class="badge badge-warning">New</span>';
        
        echo '<tr>';
        echo '<td>' . date('H:i:s', strtotime($alert['alert_time'])) . '</td>';
        echo '<td><span class="badge badge-secondary">' . $alert['alert_type'] . '</span></td>';
        echo '<td>' . $alert['message'] . '</td>';
        echo '<td><span class="badge badge-' . $severity_class . '">' . ucfirst($alert['severity']) . '</span></td>';
        echo '<td>' . $status . '</td>';
        echo '</tr>';
    }
    echo '</tbody></table>';
} else {
    echo '<p class="text-muted">No alerts found.</p>';
}
?>