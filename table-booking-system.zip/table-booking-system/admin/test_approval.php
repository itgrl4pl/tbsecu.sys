<?php
include 'header.php';
include 'includes/action_approval.php';

if(!$adminloggedin) {
    header("location: login.php");
    exit();
}

$approval = new ActionApproval($conn);
$message = '';
$message_type = '';
$pending_request = null;

// Handle form submissions
if(isset($_POST['request_approval'])) {
    $action_type = $_POST['action_type'];
    $details = [
        'item' => $_POST['item'] ?? 'Test Item',
        'reason' => $_POST['reason'] ?? 'Test reason',
        'timestamp' => date('Y-m-d H:i:s')
    ];
    
    $result = $approval->requestApproval($action_type, $details);
    
    if($result['success']) {
        $pending_request = $result;
        $message = "✅ Approval request created!";
        $message_type = 'success';
    } else {
        $message = "❌ Failed to create request";
        $message_type = 'danger';
    }
}

if(isset($_POST['verify_approval'])) {
    $token = $_POST['token'];
    $code = $_POST['code'];
    
    $result = $approval->verifyApproval($token, $code);
    
    if($result['success']) {
        $message = "✅ Approval verified! Action can now proceed.";
        $message_type = 'success';
    } else {
        $message = "❌ " . $result['message'];
        $message_type = 'danger';
    }
}

if(isset($_GET['reject'])) {
    $token = $_GET['reject'];
    $approval->rejectApproval($token);
    $message = "✅ Request rejected";
    $message_type = 'warning';
}

$pending_approvals = $approval->getPendingApprovals();
$my_requests = $approval->getMyRequests();
$stats = $approval->getStats();
?>

<div class="page-wrapper">
    <div class="content">
        <div class="row">
            <div class="col-sm-12">
                <h4 class="page-title">
                    <i class="fa fa-lock"></i> Action Approval System
                    <a href="index.php" class="btn btn-primary float-right">Dashboard</a>
                </h4>
            </div>
        </div>
        
        <?php if($message): ?>
            <div class="alert alert-<?php echo $message_type; ?> alert-dismissible fade show">
                <?php echo $message; ?>
                <button type="button" class="close" data-dismiss="alert">&times;</button>
            </div>
        <?php endif; ?>
        
        <!-- Stats Cards -->
        <div class="row mb-4">
            <div class="col-md-4">
                <div class="card bg-info text-white">
                    <div class="card-body text-center">
                        <h3><?php echo $stats['pending_approvals']; ?></h3>
                        <small>Pending Approvals</small>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card bg-primary text-white">
                    <div class="card-body text-center">
                        <h3><?php echo $stats['today_requests']; ?></h3>
                        <small>Requests Today</small>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card bg-success text-white">
                    <div class="card-body text-center">
                        <h3><?php echo $stats['approval_rate']; ?>%</h3>
                        <small>Approval Rate</small>
                    </div>
                </div>
            </div>
        </div>
        
        <div class="row">
            <!-- Request Form -->
            <div class="col-md-5">
                <div class="card">
                    <div class="card-header bg-primary text-white">
                        <h5 class="mb-0">📝 Request Approval</h5>
                    </div>
                    <div class="card-body">
                        <form method="POST">
                            <div class="form-group">
                                <label>Action Type:</label>
                                <select name="action_type" class="form-control" required>
                                    <option value="delete_booking">Delete Booking</option>
                                    <option value="cancel_booking">Cancel Booking</option>
                                    <option value="modify_price">Modify Price</option>
                                    <option value="delete_table">Delete Table</option>
                                    <option value="bulk_action">Bulk Action</option>
                                </select>
                            </div>
                            <div class="form-group">
                                <label>Item Details:</label>
                                <input type="text" name="item" class="form-control" value="Booking #12345" required>
                            </div>
                            <div class="form-group">
                                <label>Reason:</label>
                                <textarea name="reason" class="form-control" rows="2" required>Customer request</textarea>
                            </div>
                            <button type="submit" name="request_approval" class="btn btn-warning btn-block">
                                <i class="fa fa-send"></i> Request Approval
                            </button>
                        </form>
                    </div>
                </div>
                
                <?php if($pending_request): ?>
                <div class="card mt-3 border-success">
                    <div class="card-header bg-success text-white">
                        <h5 class="mb-0">🔑 Your Approval Code</h5>
                    </div>
                    <div class="card-body text-center">
                        <h1 class="display-1"><?php echo $pending_request['code']; ?></h1>
                        <p class="lead">Give this code to another admin</p>
                        <p class="text-muted">Expires: <?php echo date('H:i:s', strtotime($pending_request['expires_at'])); ?></p>
                        <div class="alert alert-warning">
                            <small>In real system, this would be emailed to approver</small>
                        </div>
                    </div>
                </div>
                <?php endif; ?>
            </div>
            
            <!-- Verify Form -->
            <div class="col-md-7">
                <div class="card">
                    <div class="card-header bg-success text-white">
                        <h5 class="mb-0">🔐 Verify Approval</h5>
                    </div>
                    <div class="card-body">
                        <form method="POST">
                            <div class="form-group">
                                <label>Approval Token:</label>
                                <input type="text" name="token" class="form-control" placeholder="Paste token from request" required>
                            </div>
                            <div class="form-group">
                                <label>6-Digit Code:</label>
                                <input type="text" name="code" class="form-control" placeholder="Enter 6-digit code" maxlength="6" required>
                            </div>
                            <button type="submit" name="verify_approval" class="btn btn-success btn-block">
                                <i class="fa fa-check-circle"></i> Verify & Approve
                            </button>
                        </form>
                    </div>
                </div>
                
                <!-- Pending Approvals (for other admins) -->
                <div class="card mt-3">
                    <div class="card-header bg-warning text-white">
                        <h5 class="mb-0">⏳ Pending Approvals (Need Your Action)</h5>
                    </div>
                    <div class="card-body">
                        <?php if(empty($pending_approvals)): ?>
                            <p class="text-muted">No pending approvals</p>
                        <?php else: ?>
                            <?php foreach($pending_approvals as $pa): ?>
                            <div class="card mb-2">
                                <div class="card-body">
                                    <div class="row">
                                        <div class="col-8">
                                            <strong><?php echo $pa['action_type']; ?></strong><br>
                                            <small>From: <?php echo $pa['requester_name']; ?></small><br>
                                            <small>Details: <?php echo json_encode($pa['action_details']); ?></small>
                                        </div>
                                        <div class="col-4 text-right">
                                            <a href="?reject=<?php echo $pa['approval_token']; ?>" class="btn btn-sm btn-danger">Reject</a>
                                        </div>
                                    </div>
                                    <div class="mt-2 text-muted small">
                                        Token: <code><?php echo substr($pa['approval_token'], 0, 16); ?>...</code><br>
                                        Code: <strong><?php echo $pa['approval_code']; ?></strong><br>
                                        Expires: <?php echo date('H:i:s', strtotime($pa['expires_at'])); ?>
                                    </div>
                                </div>
                            </div>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- My Recent Requests -->
        <div class="row mt-4">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header bg-dark text-white">
                        <h5 class="mb-0">📋 My Recent Approval Requests</h5>
                    </div>
                    <div class="card-body">
                        <table class="table table-bordered">
                            <thead>
                                <tr>
                                    <th>Time</th>
                                    <th>Action</th>
                                    <th>Details</th>
                                    <th>Code</th>
                                    <th>Status</th>
                                    <th>Expires</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if(empty($my_requests)): ?>
                                    <tr><td colspan="6" class="text-center">No requests yet</td></tr>
                                <?php else: ?>
                                    <?php foreach($my_requests as $req): ?>
                                    <tr>
                                        <td><?php echo date('H:i:s', strtotime($req['created_at'])); ?></td>
                                        <td><?php echo $req['action_type']; ?></td>
                                        <td><?php echo json_encode($req['action_details']); ?></td>
                                        <td><strong><?php echo $req['approval_code']; ?></strong></td>
                                        <td>
                                            <?php 
                                            $badge = $req['status'] == 'pending' ? 'warning' : 
                                                    ($req['status'] == 'approved' ? 'success' : 
                                                    ($req['status'] == 'rejected' ? 'danger' : 'secondary'));
                                            ?>
                                            <span class="badge badge-<?php echo $badge; ?>">
                                                <?php echo ucfirst($req['status']); ?>
                                            </span>
                                        </td>
                                        <td><?php echo date('H:i:s', strtotime($req['expires_at'])); ?></td>
                                    </tr>
                                    <?php endforeach; ?>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- Instructions -->
        <div class="card mt-4">
            <div class="card-header bg-info text-white">
                <h5 class="mb-0">📋 How to Test Two-Admin Approval</h5>
            </div>
            <div class="card-body">
                <div class="row">
                    <div class="col-md-6">
                        <h6>Test Scenario 1: Single Admin (Self-Approval)</h6>
                        <ol>
                            <li>Fill out the request form and submit</li>
                            <li>You'll get a 6-digit code</li>
                            <li>Paste the token and code in verify form</li>
                            <li>Click Verify - should approve your own request</li>
                        </ol>
                        
                        <h6>Test Scenario 2: Two Admins (Real Approval)</h6>
                        <ol>
                            <li><strong>Admin A:</strong> Create approval request</li>
                            <li><strong>Admin A:</strong> Note the 6-digit code</li>
                            <li><strong>Admin B:</strong> Login in another browser</li>
                            <li><strong>Admin B:</strong> Enter token and code in verify form</li>
                            <li><strong>Admin B:</strong> Approve the request</li>
                        </ol>
                    </div>
                    <div class="col-md-6">
                        <h6>What gets logged:</h6>
                        <ul>
                            <li> Approval requests in database</li>
                            <li> Security alerts for pending approvals</li>
                            <li> Audit trail of who approved what</li>
                            <li> Requests expire after 15 minutes</li>
                        </ul>
                        
                        <div class="alert alert-warning mt-3">
                            <strong>💡 Tip:</strong> To test with two admins:
                            <ol>
                                <li>Open Chrome (Admin A)</li>
                                <li>Open Firefox/Edge (Admin B)</li>
                                <li>Login with different admin accounts</li>
                            </ol>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php include 'footer.php'; ?>